import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  MessageCircle, 
  PhoneCall, 
  Users, 
  TrendingUp, 
  ShieldCheck, 
  Clock, 
  ChevronDown, 
  Menu, 
  X, 
  ArrowRight,
  Wallet,
  Target,
  AlertCircle,
  Sparkles,
  Award,
  Zap,
  Accessibility,
  Eye,
  Type,
  RotateCcw,
  Languages,
  Sun,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Video,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { cn } from './lib/utils';
import { saveLeadToCloud, getSettingsFromCloud, syncLeadToAppsScript, markLeadAsSynced } from './lib/firebase';
import AdminDashboard from './components/AdminDashboard';
const logoImg = "https://i.postimg.cc/W3P3rTWb/Gemini-Generated-Image-l050pdl050pdl050-removebg-preview.png";
const maozProfileImg = 'https://i.postimg.cc/sDsgcL0j/Chat-GPT-Image-Jun-9-2026-12-51-31-AM.png';

// --- Components ---

const Button = ({ 
  children, 
  className, 
  variant = 'primary', 
  size = 'md',
  ...props 
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { 
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'accent' | 'wa';
  size?: 'sm' | 'md' | 'lg';
}) => {
  const variants = {
    primary: 'bg-gradient-to-r from-gold-premium to-[#EAD2B2] text-slate-950 hover:brightness-105 font-black relative overflow-hidden shadow-lg shadow-gold-premium/15 border border-gold-premium/30',
    secondary: 'bg-navy-deep text-white hover:bg-navy-medium border border-gold-premium/30 font-extrabold shadow-sm',
    accent: 'bg-gradient-to-r from-gold-hover to-gold-premium text-slate-950 hover:brightness-110 font-black tracking-wide border border-gold-premium/20 shadow-lg shadow-gold-premium/20',
    outline: 'border-2 border-gold-premium text-gold-premium hover:bg-gold-premium/5 px-6 font-extrabold',
    wa: 'bg-[#25D366] text-white hover:brightness-105 font-black flex items-center justify-center gap-2 shadow-md shadow-green-500/10',
    ghost: 'text-slate-600 hover:text-slate-900 font-bold transition-colors',
  };
  const sizes = {
    sm: 'px-4 py-2.5 text-sm rounded-xl',
    md: 'px-6 py-3.5 text-base rounded-2xl',
    lg: 'px-12 py-5 text-lg rounded-[1.25rem]',
  };

  const isAnimated = variant === 'primary' || variant === 'accent' || variant === 'wa';

  return (
    <motion.button 
      whileHover={{ 
        scale: 1.05, 
        y: -2,
        transition: { type: "spring", stiffness: 400, damping: 10 } 
      }}
      whileTap={{ scale: 0.96 }}
      animate={isAnimated ? {
        boxShadow: variant === 'wa' ? [
          "0 4px 14px 0 rgba(37, 211, 102, 0.2)",
          "0 4px 20px 10px rgba(37, 211, 102, 0.15)",
          "0 4px 14px 0 rgba(37, 211, 102, 0.2)"
        ] : [
          "0 4px 14px 0 rgba(243, 198, 63, 0.25)",
          "0 4px 20px 10px rgba(243, 198, 63, 0.18)",
          "0 4px 14px 0 rgba(243, 198, 63, 0.25)"
        ]
      } : undefined}
      transition={isAnimated ? {
        boxShadow: {
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }
      } : undefined}
      className={cn(
        'transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer relative',
        variants[variant],
        sizes[size],
        className
      )}
      {...(props as any)}
    >
      {/* Glare effect on hover */}
      {isAnimated && (
        <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full hover:animate-shimmer" />
      )}
      {children}
    </motion.button>
  );
};


const Logo = ({ 
  className, 
  variant = 'horizontal', 
  color = 'dark' 
}: { 
  className?: string; 
  variant?: 'horizontal' | 'vertical' | 'icon'; 
  color?: 'dark' | 'light';
}) => {
  return (
    <div className={cn(
      "inline-flex items-center justify-center select-none hover:scale-[1.02] transition-all duration-300",
      className
    )}>
      <img 
        src={logoImg} 
        alt="אדר התחלה חדשה - אתגר 45 יום" 
        className={cn(
          "object-contain",
          variant === 'vertical' ? "h-36 md:h-44 w-auto" : "h-24 md:h-32 w-auto select-none"
        )}
        referrerPolicy="no-referrer"
      />
    </div>
  );
};

const SectionHeading = ({ 
  title, 
  subtitle, 
  centered = true,
  inverted = false,
  titleClassName
}: { 
  title: string; 
  subtitle?: string; 
  centered?: boolean;
  inverted?: boolean;
  titleClassName?: string;
}) => (
  <div className={cn('mb-4', centered ? 'text-center' : 'text-right')}>
    <motion.h2 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={cn(
        'text-3xl md:text-5xl font-extrabold mb-4 tracking-tight',
        titleClassName ? titleClassName : (inverted ? 'text-white' : 'text-text-main')
      )}
    >
      {title}
    </motion.h2>
    {subtitle && (
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.1 }}
        className={cn(
          'text-lg md:text-xl max-w-2xl mx-auto',
          'text-text-dim'
        )}
      >
        {subtitle}
      </motion.p>
    )}
  </div>
);

// --- Sections ---

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'אתגר 45 יום', href: '#challenge' },
    { name: 'סילבוס - 40 שיעורים מתנה', href: '#syllabus' },
    { name: 'מי אני', href: '#about' },
  ];

  return (
    <header 
      className={cn(
        'fixed top-0 w-full z-50 transition-all duration-300 py-3 h-28 md:h-36 flex items-center',
        isScrolled ? 'bg-navy-deep/95 backdrop-blur-md border-b border-white/10 shadow-lg' : 'bg-navy-deep/40 backdrop-blur-xs'
      )}
    >
      <div className="container mx-auto px-6 flex items-center justify-between">
        <div className="cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <Logo variant="horizontal" color="light" />
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              className="text-sm font-bold text-slate-200 hover:text-gold-premium transition-colors"
            >
              {link.name}
            </a>
          ))}
          <Button variant="primary" size="sm" onClick={() => document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' })}>
            מתחילים עכשיו
          </Button>
        </nav>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden p-2 text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-navy-deep/95 border-b border-white/10 absolute top-full w-full overflow-hidden shadow-xl"
          >
            <div className="flex flex-col p-8 gap-6">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href}
                  className="text-xl font-bold text-white py-2 border-b border-white/5"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              <Button variant="primary" className="w-full" onClick={() => setIsMobileMenuOpen(false)}>
                הצטרפות לאתגר
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

const Hero = () => (
  <section className="relative pt-28 pb-20 md:pt-36 md:pb-24 bg-gradient-to-b from-navy-deep via-navy-medium to-navy-deep overflow-hidden text-right border-b border-white/5" dir="rtl">
    {/* Dynamic Radial Ambient Lights */}
    <div className="absolute top-1/4 left-1/12 w-[35rem] h-[35rem] bg-gold-premium/10 rounded-full blur-[120px] pointer-events-none -translate-y-1/2" />
    <div className="absolute top-1/3 right-1/12 w-[30rem] h-[30rem] bg-gold-premium/5 rounded-full blur-[110px] pointer-events-none -translate-y-1/2" />
    
    <div className="container mx-auto px-6 relative z-10">
      <div className="max-w-5xl mx-auto text-center">
        {/* Animated Headline */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="flex justify-center mb-8"
          >
            <Logo variant="vertical" />
          </motion.div>
          
          <h1 className="text-4xl md:text-7xl font-black mb-6 leading-[1.1] tracking-tight text-white">
            אדר התחלה חדשה <br />
            <span className="text-gold-premium text-2xl md:text-4xl block mt-3 font-bold">
              אתגר כלכלי דיגיטלי של 45 יום – הדרך להתחלה החדשה שלכם מתחילה כאן!
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-slate-300 mb-8 max-w-4xl mx-auto leading-relaxed font-bold">
            אם לא תלמדו לנהל את הכסף שלכם, מישהו אחר ינהל אותו במקומכם: הבנק, חברות האשראי, ההלוואות וההוצאות השוטפות. <br className="hidden md:inline" />
            הגיע הזמן לקחת שליטה ולהפוך את הכסף המבוזבז לכלי שמשרת את המטרות שלכם, למען ההווה והעתיד שלכם.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <Button 
              variant="primary" 
              size="lg" 
              className="w-full sm:w-auto text-lg scale-105 hover:scale-110 shadow-xl shadow-gold-premium/25 transition-all"
              onClick={() => document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' })}
            >
              הצטרפו לאתגר עכשיו
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

const ContactCard = () => {
  const [formState, setFormState] = useState({ name: '', phone: '', email: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);
    try {
      // 1. Save lead to Firestore
      const leadId = await saveLeadToCloud({
        name: formState.name,
        phone: formState.phone,
        email: formState.email,
      });

      // 2. Perform automatic background sync if Google Apps Script Web App URL is configured
      try {
        const settings = await getSettingsFromCloud();
        const scriptUrl = (settings && settings.scriptUrl) || 'https://script.google.com/macros/s/AKfycbwaKDY1OTMFek5s_dxlj03C1LOo6TF2HpVzHVRGM-0I0lUAFnXvJVZPkp1cPaIkTxFLSA/exec';
        
        if (scriptUrl) {
          const syncSuccess = await syncLeadToAppsScript(scriptUrl, {
            name: formState.name,
            phone: formState.phone,
            email: formState.email,
          });
          
          if (syncSuccess && leadId) {
            await markLeadAsSynced(leadId);
          }
        }
      } catch (syncErr) {
        console.warn("Automatic Google Sheets sync skipped or failed:", syncErr);
      }

      setIsSuccess(true);
    } catch (err) {
      console.error("Failed to submit lead:", err);
      setError("אירעה שגיאה בשמירת הפרטים בבסיס הנתונים בענן. אנא נסו שוב.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-navy-medium border border-gold-premium/30 p-10 rounded-2xl shadow-xl relative"
    >
      <div className="absolute -top-4 right-4 left-4 md:right-8 md:left-auto text-center md:text-right bg-navy-light text-white font-black px-3.5 py-1.5 rounded-full text-[10px] md:text-xs uppercase tracking-wider border border-gold-premium/40 shadow-md">
        התחילו כבר עכשיו את האתגר הכלכלי דיגיטלי אדר התחלה חדשה 45 יום
      </div>
      
      {!isSuccess ? (
        <>
          <h2 className="text-3xl font-black mb-2 text-white">מתחילים עכשיו</h2>
          <p className="text-slate-300 text-sm mb-8 font-medium">השאירו פרטים ונחזור אליכם עם כל המידע על האתגר</p>
          
          {error && (
            <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-500/25 text-rose-300 text-xs font-bold text-right leading-relaxed mb-4">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <input 
              type="text" 
              placeholder="שם מלא"
              className="w-full bg-navy-deep border border-gold-premium/20 rounded-lg px-5 py-4 focus:border-gold-premium outline-none transition-colors text-white placeholder-slate-500"
              required
              value={formState.name}
              onChange={e => setFormState({...formState, name: e.target.value})}
            />
            <input 
              type="tel" 
              placeholder="מספר טלפון"
              className="w-full bg-navy-deep border border-gold-premium/20 rounded-lg px-5 py-4 focus:border-gold-premium outline-none transition-colors text-right text-white placeholder-slate-500"
              required
              value={formState.phone}
              onChange={e => setFormState({...formState, phone: e.target.value})}
            />
            <input 
              type="email" 
              placeholder="כתובת אימייל (אופציונלי)"
              className="w-full bg-navy-deep border border-gold-premium/20 rounded-lg px-5 py-4 focus:border-gold-premium outline-none transition-colors text-white placeholder-slate-500"
              value={formState.email}
              onChange={e => setFormState({...formState, email: e.target.value})}
            />
            
            <Button variant="primary" size="lg" className="w-full mt-4" disabled={isSubmitting}>
              {isSubmitting ? 'מעבד...' : 'אני רוצה להצטרף'}
            </Button>
          </form>

          <Button variant="wa" size="md" className="w-full mt-4" onClick={() => window.open('https://wa.me/972542516100?text=%D7%94%D7%99%D7%99%20%D7%90%D7%A0%D7%99%20%D7%9E%D7%A2%D7%95%D7%A0%D7%99%D7%99%D7%9F%20%D7%9C%D7%A9%D7%9E%D7%95%D7%A2%20%D7%A4%D7%A8%D7%98%D7%99%D7%9D%20%D7%A2%D7%9C%20%D7%94%D7%90%D7%AA%D7%92%D7%A8')}>
            <MessageCircle className="w-5 h-5" />
            שלחו הודעה ב-Whatsapp
          </Button>
        </>
      ) : (
        <div className="text-center py-12">
          <div className="w-20 h-20 bg-green-950/50 border border-green-500/30 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-12 h-12 text-[#25D366]" />
          </div>
          <h3 className="text-2xl font-bold mb-3 text-white">הפרטים התקבלו!</h3>
          <p className="text-slate-300 font-medium">נציג מטעמנו יצור אתכם קשר בהקדם.</p>
          <button onClick={() => setIsSuccess(false)} className="mt-8 text-gold-premium font-bold hover:underline">חזרה</button>
        </div>
      )}
    </motion.div>
  );
};

const PersonalJourney = () => {
  return (
    <section className="py-16 bg-white text-slate-900 border-t border-slate-100" id="personal-journey">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center mb-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 bg-gold-premium/10 border border-gold-premium/30 rounded-full px-4 py-1 text-xs font-black mb-2 text-gold-premium tracking-widest uppercase"
          >
            איך הכל התחיל ולמה...
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-2xl md:text-4xl font-black text-slate-950 mb-4 leading-tight"
          >
            למה הגעתי לתחום של כלכלת המשפחה?
          </motion.h2>

          {/* Divider line */}
          <motion.div
            initial={{ opacity: 0, scaleX: 0 }}
            whileInView={{ opacity: 1, scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="w-16 h-1 bg-gold-premium mx-auto mb-4 rounded"
          />
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="text-base md:text-lg text-slate-800 max-w-3xl mx-auto font-bold leading-snug space-y-2 mb-6 text-right md:text-center"
          >
            <p>
              את הידע וההבנה שלי בתחום כלכלת המשפחה רכשתי מתוך ניסיון אישי, 
              ומתוך התבוננות בהתנהלות הכלכלית, של כל המעגל הקרוב שבו גדלתי.
              החוויות וההתמודדויות היומיומיות בסביבה זו העניקו לי הבנה מעמיקה של התנהלות כלכלית  ושל האתגרים העומדים בפני משפחות שונות.
            </p>
            <p className="text-slate-650 text-sm md:text-base">
              בכל אופן, זה החומר שתכלס אתם צריכים להכיר אותו בלי לחוות את כל ה״כאב״ ו״הטעויות״ שאני ראיתי ועשיתי בחיי. (ואם אתם, אתה, את, אתן, נמצאים במקום של כאב וחנוקים עכשיו תדעו שלעשות שינוי עכשיו זה אפשרי!).
            </p>
            
            <div className="pt-4 border-t border-slate-150 flex flex-col gap-2 text-right text-slate-800 font-bold text-sm md:text-base leading-snug bg-slate-50 border border-gold-premium/25 p-4 rounded-xl shadow-xs">
              <p className="text-gold-premium font-black text-base md:text-lg leading-snug">
                אשתף אתכם שהוצאת המדריך הדיגיטלי הזה נולד מהכאב האישי שלי. על הכאב המדובר שילמתי עם השנים הרבה מאוד כסף!
              </p>
              <p className="font-bold text-slate-900">
                חובות של מאות אלפי שקלים ויותר מכך שהיו שייכים למשפחתי בגלל טעויות שהיה אפשר למנוע אותם אם רק היה לי טיפה מהידע שיש לי היום אז!
              </p>
              <p className="text-slate-650 font-medium italic">
                זה היה מונע ממני וממשפחתי הרבה כאב, וטעויות כה רבות הקשורות לניהול הכסף בתא המשפחתי שמלוות בתחושות שעדיין מלוות אותנו עד היום.
              </p>
            </div>
          </motion.div>
        </div>

        <div className="max-w-4xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-slate-50 text-slate-800 rounded-[2rem] p-8 md:p-12 shadow-sm border border-gold-premium/20 relative overflow-hidden"
          >
            {/* Ambient radiant glowing effects */}
            <div className="absolute -top-12 -right-12 w-48 h-48 bg-gold-premium/5 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-gold-premium/5 rounded-full blur-3xl pointer-events-none" />
            
            <div className="relative z-10">
              <p className="text-base md:text-xl font-bold leading-snug whitespace-pre-line text-justify md:text-right">
                {`את הדרך של ״אדר התחלה החדשה״ למדתי מהשטח מאותו ״כאב גדול״ של המשפחה שלי, ושל אותם המשפחות שהכרתי במהלך השנים.

כשהייתי צעיר, סביבות גיל 10, יצאתי לעבוד בכל עבודה שהתאפשרה לי החל משיפוצים בניה והובלות וכל עבודה מזדמנת אחרת. כל הכנסה שהרווחתי חסכתי בקפדנות, מתוך מטרה לבנות לעצמי ולמשפחתי ביטחון כלכלי ולהבטיח עתיד יציב. כבר מגיל צעיר הבנתי את ערכו של הכסף ואת החשיבות של התנהלות כלכלית אחראית, חיסכון והתמדה.

כל הכנסה עברה מיד לטובת כלכלת המשפחה שלי, ולטובת צמצום החובות שנצברו במשפחתי.

כיום כיועץ מורשה וכבעל עסק, וכשכיר בעבודה שאני אוהב, ומתנדב במגוון עמותות שמסייעות ותורמות למשפחות רבות, אני מזהה את הכאב והקושי אצל כולם! (גם אצל אלו שהמצב הכלכלי שלהם לא רע!).

הכאב שהרגשתי כילד הוא זהה בדיוק לכאב של אותם האנשים שאני ליוויתי בחיי בתהליך הליווי של כלכלת המשפחה אחד על אחד וגם במפגשים אקראיים בחיי הקהילה.`}
              </p>
            </div>
          </motion.div>
        </div>

      </div>
    </section>
  );
};

const Challenge = () => (
  <section className="py-16 bg-navy-deep border-t border-white/5" id="challenge" dir="rtl">
    <div className="container mx-auto px-6">
      <div className="max-w-3xl mx-auto text-right">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="space-y-6"
        >
          <div>
            <div className="flex justify-start mb-6">
              <Logo variant="horizontal" />
            </div>
            <h2 className="text-2xl md:text-3xl font-black text-white mb-6 leading-tight">
              למה אתגר 45 יום ״אדר התחלה חדשה״?
            </h2>
            <p className="text-base md:text-lg text-slate-300 leading-relaxed font-semibold mb-4">
              כי ההתנהלות הכלכלית שלך זה כמו ״שריר״ שצריך לחזק אותו כל הזמן ולעבוד עליו כל הזמן, ללמוד הרגלים חדשים וללמוד להתנהג עם הכסף שלכם גם בתקופות של מלחמה וגם בשגרה. האתגר נבנה בדיוק מהצורך של משפחות רבות ואנשים מכל הגילאים שנקלעו למצוקה כלכלית בעקבות התנהלות לא נכונה וטעויות רבות שכדאי להימנע מהן.
            </p>
            <p className="text-base md:text-lg text-slate-300 leading-relaxed font-semibold mb-4">
              <span className="text-gold-premium font-black">כל שיעור בנוי עד 30 דק:</span> זמין ונוח להאזנה בכל מקום ובכל זמן. זה בדיוק מה שצריך כדי להצליח באתגר. כדי לצלוח אותו כדאי להתחיל עם המדריך הכלכלי הדיגיטלי של 40 השיעורים.
            </p>
            <p className="text-base md:text-lg text-slate-300 leading-relaxed font-semibold mb-4">
              <span className="text-gold-premium font-black">ראו הוזהרתם...</span> זה לא מתאים לכל מי שצריך ״יד ביד״. מדובר בהתנסות ולמידה עצמית! כדי להצליח באתגר עליכם להבין שמדובר בלמידה עצמית באופן מקוון, בכל זמן ובכל מקום.
            </p>
            <p className="text-base md:text-lg text-slate-300 leading-relaxed font-semibold">
              <span className="text-gold-premium font-black">טיפ חשוב להצלחה:</span> כדי להצליח באתגר הכלכלי הדיגיטלי שישנה לכם את החשיבה על כסף, אתם קודם כל צריכים לסלוח לעצמכם על טעויות העבר. מה שהיה היה ולא ניתן לשנות אותו. מה שחשוב הרבה יותר הוא ההווה ותכנון העתיד הכלכלי שלכם.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

const Benefits = () => {
  const list = [
    {
      title: "40 שיעורים דיגיטליים במתנה",
      description: "כל שיעור בנוי עד 30 דק - זמין ונוח להאזנה בכל מקום ובכל זמן, ללמידה עצמית וקלה מכל מקום שתרצו."
    },
    {
      title: "אתגר 45 הימים",
      description: "משימה מעשית ממוקדת בכל יום לפיתוח הרגלים כלכליים נכונים וחיזוק השריר הפיננסי שלך בשטח."
    },
    {
      title: "גישה מלאה למשך שנה",
      description: "למידה בקצב האישי שלכם, 24/7, עם אפשרות לחזור על השיעורים ולהתחיל מחדש כמה שרק תצטרכו."
    }
  ];

  return (
    <section className="py-16 bg-white border-t border-slate-150" id="benefits" dir="rtl">
      <div className="container mx-auto px-6 max-w-5xl">
        <SectionHeading 
          title="מה אתם מקבלים בהצטרפות לאתגר?" 
          subtitle="כל הכלים, הידע והתמיכה הדיגיטלית שאתם צריכים כדי לצאת לדרך כלכלית חדשה ומנצחת."
          inverted={false}
          titleClassName="text-black"
        />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
          {list.map((item, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="p-6 rounded-2xl bg-slate-50 border border-gold-premium/20 hover:border-gold-premium/50 hover:shadow-md hover:shadow-gold-premium/5 transition-all duration-300 text-right flex flex-col gap-2"
            >
              <div className="space-y-1.5">
                <h3 className="text-lg font-black text-black">{item.title}</h3>
                <p className="text-sm font-semibold text-black leading-snug">{item.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Syllabus = () => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  const chapters = [
    {
      title: "פרק 1 - הצעד הראשון",
      lessons: [
        "שיעור 1 - זיהוי ושינוי פרדיגמה",
        "שיעור 2 - השינוי",
        "שיעור 3 - נכס מול התחייבות",
        "שיעור 4 - דרך לכוון ולהוביל",
        "שיעור 5 - הדרך שלי",
        "שיעור 6 - מינוס עולה לי כסף",
        "שיעור 7 - זמן לשתף"
      ]
    },
    {
      title: "פרק 2 - חוקי פלדה",
      lessons: [
        "שיעור 8 - חוקי פלדה",
        "שיעור 9 - חוקי פלדה",
        "שיעור 10 - מודל האדם העני",
        "שיעור 11 - מודל האדם העשיר"
      ]
    },
    {
      title: "פרק 3 - עבודת צוות",
      lessons: [
        "שיעור 12 - הזמן לסדר",
        "שיעור 13 - מעקב אחרי השקל",
        "שיעור 14 - עבודת צוות"
      ]
    },
    {
      title: "פרק 4 - צרכנות נבונה",
      lessons: [
        "שיעור 15 - מינויים שהזול ביותר ינצח",
        "שיעור 16 - זמן איכות התחלה חדשה",
        "שיעור 17 - חוסכים כסף",
        "שיעור 18 - צרכנות נבונה"
      ]
    },
    {
      title: "פרק 5 - מהי הוצאה ומהי הכנסה",
      lessons: [
        "שיעור 19 - חישוב הכנסות שכיר",
        "שיעור 20 - חישוב הוצאות",
        "שיעור 21 - חישוב הוצאות, חסכונות והשקעות",
        "שיעור 22 - חישוב הכנסות עצמאי"
      ]
    },
    {
      title: "פרק 6 - מה יקרה אם?",
      lessons: [
        "שיעור 23 - חישוב הוצאות בלתי מתוכננות",
        "שיעור 24 - כמה חשוב שיהיה קופת בלתם"
      ]
    },
    {
      title: "פרק 7 - ליישם ולתרגל",
      lessons: [
        "שיעור 25 - לומדים את הדרך הנכונה",
        "שיעור 26 - רושמים הכל",
        "שיעור 27 - אוספים הכנסות 3 חודשים",
        "שיעור 28 - אוספים הוצאות 3 חודשים"
      ]
    },
    {
      title: "פרק 8 - העתיד שלי",
      lessons: [
        "שיעור 29 - הכסף שלכם נמצא כאן",
        "שיעור 30 - מטרות כלכליות",
        "שיעור 31 - מטרות כלכליות חלק ב"
      ]
    },
    {
      title: "פרק 9 - כרטיסי אשראי",
      lessons: [
        "שיעור 32 - כרטיס אשראי",
        "שיעור 33 - כרטיס אשראי הדרך לשום המקום"
      ]
    },
    {
      title: "פרק 10 - מוצרים פיננסים",
      lessons: [
        "שיעור 34 - היכרות עם מוצרים פיננסים",
        "שיעור 35 - מוצרים פיננסים",
        "שיעור 36 - מוצרים פיננסים חלק ב",
        "שיעור 37 - מוצרים פיננסים חלק ג"
      ]
    },
    {
      title: "פרק 11 - מוצרים פנסיונים",
      lessons: [
        "שיעור 38 - מוצרים פנסיונים",
        "שיעור 39 - מוצרים פנסיונים",
        "שיעור 40 - מוצרים פנסיונים"
      ]
    }
  ];

  return (
    <section className="py-16 bg-navy-medium border-t border-white/5" id="syllabus" dir="rtl">
      <div className="container mx-auto px-6 max-w-4xl">
        <SectionHeading 
          title="סילבוס מדריך כלכלי דיגיטלי אדר התחלה חדשה 40 שיעורים פרקטיים בכלכלת המשפחה" 
          subtitle="סילבוס המדריך הדיגיטלי אדר התחלה חדשה - 40 שיעורים פרקטיים בכל הנושא שמסכם את המושג כלכלת המשפחה"
          inverted={true}
        />
        
        <div className="flex justify-center mt-3 mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold-premium/10 border border-gold-premium/30 rounded-2xl text-gold-premium font-black text-xs md:text-sm shadow-xs text-center leading-snug">
            <span>רק משתתפי האתגר מקבלים גם את 40 שיעורים במתנה ללא עלות!</span>
          </div>
        </div>
        
        <div className="space-y-3 mt-8">
          {chapters.map((chapter, i) => (
            <div key={i} className="border border-gold-premium/20 rounded-xl overflow-hidden bg-navy-deep shadow-sm hover:border-gold-premium/40 transition-colors">
              <button 
                className="w-full p-4 text-right flex items-center justify-between hover:bg-white/5 transition-colors"
                onClick={() => setExpandedIndex(expandedIndex === i ? null : i)}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-navy-medium text-gold-premium flex items-center justify-center font-bold text-sm border border-gold-premium/30 shadow-sm shrink-0">
                    {i + 1}
                  </div>
                  <span className="text-base font-bold text-white leading-none">
                    {chapter.title}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-400">
                    {chapter.lessons.length} שיעורים
                  </span>
                  <ChevronDown className={cn("w-4 h-4 text-gold-premium transition-transform duration-300", expandedIndex === i && "rotate-180")} />
                </div>
              </button>
              
              <AnimatePresence initial={false}>
                {expandedIndex === i && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="px-6 pb-5 pt-2 border-t border-gold-premium/20 bg-navy-medium/40">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {chapter.lessons.map((lesson, j) => (
                          <div key={j} className="flex items-center gap-2.5 text-slate-300 p-2 bg-navy-deep border border-gold-premium/15 rounded-lg shadow-sm">
                            <CheckCircle2 className="w-4 h-4 text-[#25D366]" />
                            <span className="text-sm font-semibold text-slate-300">{lesson}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Pricing = () => {
  const plans = [
    {
      name: 'מדריך דיגיטלי כלכלי 40 שיעורים',
      price: '₪697',
      description: 'מדריך דיגיטלי אדר התחלה חדשה הכולל 40 שיעורי יסוד בכלכלת המשפחה מוקלטים בכל זמן וכל מקום! ללא גישה והשתתפות באתגר 45 יום.',
      features: [
        'מדריך דיגיטלי אדר התחלה חדשה',
        '40 שיעורי יסוד מוקלטים',
        'זמין בכל זמן ומכל מקום!',
        'ללא גישה והשתתפות באתגר 45 יום'
      ],
      cta: 'רכישת המדריך בלבד',
      recommend: false,
      isPremium: false
    },
    {
      name: 'אתגר 45 יום - בסיסי',
      price: '₪897',
      description: 'חבילה בסיסית להשתתפות באתגר הדיגיטלי המלא.',
      features: [
        'גישה מלאה לאתגר 45 יום',
        'ללא מפגש זום',
        '40 שיעורי יסוד במתנה!',
        'קבצי עבודה ותבניות פרקטיות'
      ],
      cta: 'מתחילים עכשיו',
      recommend: false,
      isPremium: false
    },
    {
      name: 'אתגר 45 יום - מתקדם',
      price: '₪1,497',
      description: 'המסלול המבוקש ביותר כולל פגישה אישית איתי לדיוק התוצאות שלכם.',
      features: [
        'גישה מלאה לאתגר 45 יום',
        'כולל 1 פגישת זום אישית (60 דק׳)',
        '40 שיעורי יסוד במתנה!',
        'מענה על שאלות ודיוק מטרות'
      ],
      cta: 'הצטרפות למסלול מתקדם',
      recommend: true,
      isPremium: false
    },
    {
      name: 'אתגר 45 יום - פרימיום',
      price: '₪1,897',
      description: 'המעטפת המלאה ביותר עם ליווי זום כפול לפריצת דרך מקסימלית.',
      features: [
        'גישה מלאה לאתגר 45 יום',
        'כולל 2 מפגשי זום של 60 דק\' כל אחד',
        '40 שיעורי יסוד במתנה!',
        'תבניות אקסל מתקדמות וליווי צמוד'
      ],
      cta: 'הצטרפות לפרמיום',
      recommend: false,
      isPremium: true
    }
  ];

  return (
    <section className="py-16 bg-navy-deep border-t border-white/5" id="pricing" dir="rtl">
      <div className="container mx-auto px-6">
        <SectionHeading title="בחרו את המסלול שלכם" subtitle="השקעה בעתיד שלכם היא ההשקעה עם התשואה הגבוהה ביותר." inverted={true} />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto mt-8">
          {plans.map((plan, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={cn(
                "p-6 rounded-2xl bg-navy-medium border flex flex-col items-center text-center relative transition-all duration-300 hover:scale-[1.03] shadow-md text-white",
                plan.isPremium
                  ? "border-gold-premium border-2 shadow-xl shadow-gold-premium/15 scale-105 z-10"
                  : plan.recommend 
                    ? "border-gold-premium border-2 shadow-xl shadow-gold-premium/15 scale-105 z-10" 
                    : "border-gold-premium/20 hover:border-gold-premium/50"
              )}
            >
              {plan.isPremium && (
                <div className="absolute -top-3 bg-gradient-to-r from-gold-premium to-[#EAD2B2] text-navy-deep shadow-md shadow-gold-premium/15 px-3.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1">
                  <span>חבילת פרימיום</span>
                </div>
              )}
              {plan.recommend && !plan.isPremium && (
                <div className="absolute -top-3 bg-gold-premium text-navy-deep shadow-md shadow-gold-premium/15 px-3.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-widest">
                  הכי פופולרי
                </div>
              )}
              <h3 className="text-base font-black text-white mb-1 select-none">
                {plan.name}
              </h3>
              <p className="text-[11px] text-slate-300 leading-snug font-bold mb-4 min-h-[50px] flex items-center justify-center">
                {plan.description}
              </p>
              <div className={cn(
                "text-2xl font-black mb-4 px-5 py-2 border rounded-2xl shadow-xs min-w-[130px] text-center font-mono select-all",
                plan.isPremium 
                  ? "bg-gold-premium/10 text-gold-premium border-gold-premium/30"
                  : "bg-navy-deep text-white border-gold-premium/20"
              )}>
                {plan.price}
              </div>
              <ul className="space-y-2 mb-4 flex-1 w-full">
                {plan.features.map((f, j) => (
                  <li key={j} className="text-slate-300 font-bold text-[11px] lg:text-xs flex items-start gap-1.5 text-right w-full justify-start">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0 mt-0.5 text-gold-premium" />
                    <span className="leading-snug">{f}</span>
                  </li>
                ))}
              </ul>
              <Button 
                variant={plan.isPremium ? 'primary' : plan.recommend ? 'primary' : 'outline'} 
                className={cn(
                  "w-full py-2.5 text-xs font-black mt-2",
                  plan.isPremium
                    ? "bg-gradient-to-r from-gold-premium to-[#EAD2B2] text-slate-950 border border-gold-premium/30 shadow-sm hover:brightness-105"
                    : plan.recommend 
                      ? "bg-gold-premium text-navy-deep hover:bg-gold-hover border border-gold-premium"
                      : "text-white border-white/20 hover:bg-white/5"
                )}
                onClick={() => document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' })}
              >
                {plan.cta}
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const About = () => (
  <section className="py-16 bg-white border-t border-slate-150" id="about" dir="rtl">
    <div className="container mx-auto px-6 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-right"
      >
        <h2 className="text-2xl md:text-3xl font-black text-slate-950 mb-8 text-right underline decoration-gold-premium/30 underline-offset-8">
          מי אני?
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          {/* Text & Stats column */}
          <div className="md:col-span-6 space-y-6 order-1">
            <div className="text-slate-800 font-medium text-sm md:text-base leading-relaxed text-right space-y-4">
              <p className="text-slate-950 font-extrabold text-base md:text-lg">
                אז למי שעדיין לא מכיר אותי, שמי מעוז אדר.
                <br />
                יועץ ומלווה משפחות שמתקשות לסגור את החודש בגלל התנהלות כלכלית לא נכונה, סוכן נדל"ן מורשה, משקיע בשוק ההון, ואבא לאימרי שלום כבן 7, ואח לעוד 6 אחים נוספים.
              </p>
              <p>
                גדלנו במשפחה מרובת ילדים (בת 9 נפשות), בדירת ״עמידר״ בת 4 חדרים. אבי (ז״ל) היה חולה סוכרת שעבד בעבודות מזדמנות, ואמי (שתחיה לשנים ארוכות וטובות) הייתה, ועודנה, חולת לב שהקדישה את חייה לגידול הילדים. המעמסה הרפואית והמשפחתית מנעה מהם להתפרנס כראוי.
              </p>
              <p>
                חיינו בבית מלא חום, תמיכה ואהבה גדולה, אך כסף תמיד היה חסר.
                <br />
                כיום אני יודע לומר שגדלנו בילדות של פעם, אשר דרשה מאיתנו להיות מרוצים מהמצב וליהנות ממה שיש.
              </p>
              <p>
                התמודדנו עם חובות שהלכו ותפחו, התנהלות כלכלית שגויה מהיסוד, פקודות מעצר, עיקולים על ידי הוצאה לפועל והפסקות חשמל תדירות. כל אלה היו חלק מהשגרה שלנו כיל.
                <br />
                רק לאחר שהתבגרנו, הבנו שזהו לא באמת מצב שגרתי שמשפחות צריכות לעבור אותו.
                <br />
                ומאז, לקחתי על עצמי את האתגר ללמוד למה זה קרה ומה הוביל אותנו למצב הזה.
                <br />
                לאחר שנחשפתי לכל העולם הזה שנקרא כלכלת המשפחה מגיל צעיר מאוד, הבנתי את הערך של לצאת לעבוד מגיל קטן, לחסוך כסף ולשלם איתו את החשבונות והחובות.
              </p>
              <p>
                במהלך החיים, החלטתי לחקור, ללמוד ולעשות לזה סוף. למדתי כלכלה ומנהל עסקים, אלקטרוניקה ומכונות. שירתתי כ-8 שנים כלוחם ומפקד בשריון, ועוד כ-3 שנים במשטרת ישראל כחוקר פלילי ועבירות כלכליות.
              </p>
              <p>
                כיום, אני יועץ ומדריך מוסמך בתחום כלכלת המשפחה ובתכנון כלכלי אסטרטגי למשפחות ולעסקים קטנים. ליוויתי בהצלחה עשרות משפחות מכל קצוות הארץ ומכל שכבות הגיל (מגיל 15 ועד 67 ואף יותר).
                <br />
                בנוסף אני משלב את ייעוץ והליווי כלכלת המשפחה גם כיועץ נדל"ן ובתהליך של רכישת דירה ומכירת דירה וניהול נכסים לצד זוגות צעירים, משקיעי נדל"ן וכאלו הבוחרים לשדרג את איכות החיים שלכם בדירה חדישה.
                <br />
                אני עושה זאת תוך בירור צרכים מעמיק, עמידה ביכולת לעמוד בתשלומי המשכנתא, התמודדות נכונה מול ניהול כלכלי נכון וכל זאת עד לעסקת הנדל"ן המתאימה ביותר עבור הזוג גם מבחינת הנתונים וגם מבחינת ההחזר החודשי כל זאת במטרה שהזוג באמת יוכל לרכוש את הדירה ולעמוד בתשלומים בלי להכנס לחובות מיותרים.
                <br />
                תוך ניתוח סיכונים, איתור נכסים מתחת לרדאר, וניהול משא ומתן מוצלח עד לחתימה על משכנתא, חתימה על חוזה רכישה ועוד. 
                <br />
                למשקיעי נדל"ן אני דואג לכל המעטפת של שיפוץ והשבחת הנכס, שוכרים איכותיים. וניהול הנכס כל המעטפת משלב הבירור צרכים ועד לשלב ביצוע העסקה המתאימה ביותר עבורם.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2 md:gap-4 border-t border-b border-gold-premium/20 py-5 mt-6 max-w-xl">
              {[
                { v: '7+', l: 'שנות יועץ' },
                { v: 'עשרות', l: 'משפחות שליוויתי' },
                { v: '100%', l: 'התחייבות להצלחה' }
              ].map((s, i) => (
                <div key={i} className="text-center">
                  <div className="text-xl md:text-2xl font-black text-gold-premium">{s.v}</div>
                  <div className="text-[10px] md:text-xs text-slate-500 font-bold">{s.l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Column 2 */}
          <div className="md:col-span-6 space-y-6 order-2 text-slate-800 font-medium text-sm md:text-base leading-relaxed text-right flex flex-col">
            {/* Maoz Profile Photo Container */}
            <div className="relative w-full max-w-xl mx-auto md:mr-auto md:ml-0 aspect-[4/5] rounded-[2.5rem] overflow-hidden border-2 border-gold-premium/30 shadow-2xl mb-4 group">
              <img 
                src={maozProfileImg} 
                alt="מעוז אדר" 
                className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/50 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-4 right-6 text-right">
                <span className="text-white font-black text-lg block drop-shadow-sm">מעוז אדר</span>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  </section>
);

const SurvivalState = () => (
  <>
    {/* Section 1: Survival Mindset & Personal Background */}
    <section className="py-20 bg-white border-t border-slate-150" id="survival-mindset" dir="rtl">
      <div className="container mx-auto px-6 max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="space-y-12 text-right"
        >
          {/* Header */}
          <div className="text-center md:text-right max-w-3xl">
            <h2 className="text-3xl md:text-4xl font-black text-slate-950 leading-tight mb-4">
              גדלנו על תדר הישרדותי כילדים בשכונה
            </h2>
            <p className="text-slate-600 font-bold text-base md:text-lg">
              וזו הסיבה המרכזית לכך שהחלטתי לעשות לזה סוף:
            </p>
          </div>

          {/* Cards Grid */}
          <div className="max-w-2xl mx-auto w-full">
            {/* Card: Why it happened */}
            <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm hover:border-gold-premium/30 transition-all duration-350 flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-black text-slate-950">למה היינו בחובות כלכליים ?</h3>
                <p className="text-slate-700 font-medium text-sm md:text-base leading-relaxed">
                  כי לא היה אף אחד שילמד וידריך את המשפחות שלנו, ההורים שלנו, ואותנו כשהיינו ילדים את כל התחום שנקרא ״כלכלת המשפחה״.
                </p>
              </div>
              <div className="pt-4 border-t border-slate-100">
                <span className="text-slate-500 font-bold text-xs md:text-sm block">
                  פשוט לא ידענו אז איך לקחת אחריות על הטעויות הכלכליות שלנו!
                </span>
              </div>
            </div>
          </div>

          {/* Core Insights Boxes */}
          <div className="bg-white p-8 md:p-10 rounded-[2.5rem] border border-gold-premium/20 shadow-xs space-y-6">
            <div className="flex flex-col md:flex-row gap-6 items-start md:items-center justify-between pb-6 border-b border-slate-100">
              <div className="space-y-1">
                <h4 className="text-lg font-black text-slate-950 leading-relaxed">
                  במציאות הנוכחית בישראל גורמת לנו להגיד יקר כאן וזה התירוץ של רוב האנשים להיות במינוס! אף אחד לא באמת לוקח אחריות על הניבול הלככלי שלו הרגל שגורר אחריו טעויות שעולות לכם הרבה מאוד כסף לאורך השנים!
                </h4>
              </div>
            </div>

            <p className="text-slate-800 font-semibold text-sm md:text-base leading-relaxed">
              בעקבות דרכי שלי כילד, נער, וכיום כשאני בן 34 שכל חיי ליוו אותי הטעויות הכלכליות הכל כך קריטיות החלטתי להקדיש את הזמן שלי לחקור וללמוד את התחום שנקרא ״כלכלת המשפחה בישראל״.
            </p>

            <div className="bg-gradient-to-r from-gold-premium/10 via-gold-premium/[0.03] to-transparent border-r-4 border-gold-premium p-6 rounded-l-2xl">
              <p className="font-black text-slate-950 text-base md:text-lg leading-relaxed">
                ועכשיו, לאחר שנים רבות של לימוד, ניסוי וטעייה, תרגול, ועוד קורס ועוד הכשרה ועוד לימודים בשילוב ניסיון החיים שלי אני מעביר לכם את כל הנסיון שצברתי לאורך כל חיי יחד עם התחושות, הטעויות, הרגשות שמלוות אותנו ביום יום, ואת הפתרונות לשינויי הרגלים מזיקים והטמעת הרגלים מחזקים למען הווה ועתיד טובה יותר.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>

    {/* Section 2: Why Now? & The 45-Day Challenge */}
    <section className="py-20 bg-navy-deep border-t border-white/5" id="why-now" dir="rtl">
      <div className="container mx-auto px-6 max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="space-y-12 text-right"
        >
          {/* Main Title */}
          <div className="text-center max-w-3xl mx-auto space-y-4">
            <span className="inline-block bg-rose-950/45 text-rose-300 border border-rose-500/30 font-black text-sm md:text-base px-5 py-2 rounded-full tracking-wide uppercase">
              למה דווקא עכשיו?
            </span>
            <h2 className="text-3xl md:text-4xl font-black text-white leading-tight">
              המציאות הנוכחית דורשת שינוי
            </h2>
            <p className="text-rose-400 font-extrabold text-lg md:text-xl">
              לאור המציאות הנוכחית של מלחמות, כאב גדול ואובדן שליטה.
            </p>
          </div>

          {/* Deep Insight Textbox */}
          <div className="bg-navy-medium p-6 md:p-8 rounded-[2rem] border border-gold-premium/15 space-y-6">
            <p className="text-slate-200 font-semibold text-base md:text-lg leading-relaxed">
              זיהיתי מצוקה גדולה בקרב אותן משפחות רבות שליוויתי אותם בעבר כי צריך להיות ״משהו״ מעבר לקורס כלכלת המשפחה, מעבר ליסודות הבסיסיים שכתובים בספרים כמו ״אבא עשיר ואבא עני״ – אלא "משהו" שיגרום לכם לצאת מאזור הנוחות שלכם ולייצר הרגלים מנצחים חדשים כל יום!
            </p>

            <div className="bg-gold-premium/5 border-2 border-gold-premium/20 p-6 md:p-8 rounded-2xl space-y-4">
              <h3 className="text-xl font-bold text-gold-premium">בשיטה פשוטה יותר ומעשית יותר.</h3>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  </>
);

const AfterChallenge = () => (
  <section className="py-16 bg-navy-deep border-t border-white/5" id="after-challenge" dir="rtl">
    <div className="container mx-auto px-6 max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="bg-navy-medium p-8 md:p-12 rounded-[2rem] border border-gold-premium/20 text-right text-slate-200 shadow-sm space-y-10"
      >
        {/* Block 1 */}
        <div className="space-y-4">
          <h2 className="text-2xl md:text-3xl font-black text-white leading-tight">
            מה צפוי לכם בסיום האתגר?
          </h2>
          <p className="text-slate-300 font-semibold text-base md:text-lg leading-relaxed">
            מי שיבצע את ה-40 שיעורים כבר שיפר לעצמו את הידע ואת היכולת להתנהל כלכלית טוב יותר וגם למען עתיד טוב יותר! ומי שגם ילמד את ה-40 שיעורים וגם יבצע את האתגר הכלכלי דגיטלי 45 יום ידע להתמודד עם כל המושג הזה שנקרא יוקר המחייה בישראל וייצור למשפחתו ולו עתיד כלכלי מנצח.
          </p>
        </div>

        {/* Divider line */}
        <div className="h-[1px] bg-gold-premium/20 w-full" />

        {/* Block 2 */}
        <div className="space-y-4">
          <h2 className="text-2xl md:text-3xl font-black text-white leading-tight">
            חשוב שתדעו אין מקום לוותר ולהרים ידיים!
          </h2>
          <div className="text-slate-300 font-semibold text-base md:text-lg leading-relaxed space-y-4">
            <p>
              האתגר יסייע לכם להפחית או גם להשתחרר מכל הפחדים, הלחצים, הטעויות, העומס והדאגות שאנחנו כולנו ״סוחבים״ איתנו במציאות הכלכלית הישראלית ביום יום מאז כשאנחנו ילדים קטנים ועד לחיינו הבוגרים.
            </p>
            <p>
              האתגר יתן לכם את הידע להעביר לילדים שלנו ולהטמיע בהם את הדרך הטובה ביותר להתנהלות הכלכלית המנצחת כבר בהיותם ילדים, בדיוק כפי שאני עושה עם <strong>אימרי שלום</strong> הבן שלי.
            </p>
            <p>
              חשוב לא ״לחפף״ את המשימות שיש באתגר אלא ממש להשקיע בכל משימה ומשימה מחשבה ותשומת לב גם אם זה נראה לכם ״סתם שטויות״.
            </p>
            <p>
              ואני אהיה גלוי איתכם – אם אני עברתי את זה (מדובר על תרגול יומיומי במשך שנים!!!) גם אתם יכולים!!!
            </p>
            <p className="bg-gold-premium/5 p-5 rounded-2xl border border-gold-premium/15 text-white font-extrabold">
              אם קשה לכם והפסקתם מסיבה כזאת או אחרת... אז מה אם קשה! אמרתי לכם מספר פעמים שזה לא יהיה לכם קל! אין דבר כזה קל בהתנהלות כלכלית והטמעת הרגלים חדשים. תמשיכו מאיפה שהפסקתם! תחזרו שוב על השיעורים והתחילו שוב את האתגר מההתחלה! לא לוותר. כי אין מקום לוותר.
            </p>
          </div>
        </div>

        {/* Closing/Signature inside */}
        <div className="pt-6 border-t border-gold-premium/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <p className="text-lg font-black text-white">בהצלחה בדרך להתחלה החדשה שלכם!</p>
            <p className="text-sm font-bold text-slate-400">בהערכה רבה,</p>
            <p className="text-lg font-black text-gold-premium">מעוז אדר</p>
          </div>
        </div>
      </motion.div>
    </div>
  </section>
);




const Testimonials = () => {
  const testimonials = [
    { 
      name: 'דניאל כהן', 
      role: 'שכיר, תל אביב', 
      highlight: 'סדר שלא הצלחתי לעשות לבד שנים',
      text: 'האתגר עשה לי סדר שלא הצלחתי לעשות לבד שנים. היום ב-2026, כשהכל יקר, הידע הזה הוא אוויר לנשימה עבורנו.', 
      rating: 5,
      color: 'from-amber-50/50 to-orange-50/30'
    },
    { 
      name: 'ליאת ורוני', 
      role: 'זוג פלוס 3', 
      highlight: 'מבינים לאן כל שקל הולך',
      text: 'סוף סוף אנחנו מבינים לאן הכסף הולך. השינוי בתודעה הוא מה שבאמת שינה לנו את החיים כמשפחה.', 
      rating: 5,
      color: 'from-amber-50/40 to-yellow-50/20'
    },
    { 
      name: 'עומר נ.', 
      role: 'חייל משוחרר', 
      highlight: 'בלי סיפורים, פשוט משימות וכלים שעובדים',
      text: 'הקורס הכי פרקטי שעשיתי. בלי סיפורים, פשוט משימות וכלים שעובדים. הצלחתי לחסוך הון למרות המצב בארץ.', 
      rating: 5,
      color: 'from-emerald-50/50 to-teal-50/30'
    },
    { 
      name: 'מיכל א.', 
      role: 'עצמאית בתחום העיצוב', 
      highlight: 'שינוי תודעתי מטורף בעסק',
      text: 'חשבתי שהעסק שלי יקרוס, אבל מעוז נתן לי כלים לנהל את הכספים בצורה שלא הכרתי. מומלץ בחום לכל עצמאי!', 
      rating: 5,
      color: 'from-rose-50/50 to-orange-50/30'
    },
    { 
      name: 'איתי ברקוביץ', 
      role: 'ראש משפחה, נשוי + 2', 
      highlight: 'הביטחון הכלכלי שלי היום הוא בשיא',
      text: 'הביטחון הכלכלי שלי היום הוא בשיא, וזה רק בגלל שלקחתי על עצמי את האתגר של מעוז. פשוט יצאתי לדרך חדשה.', 
      rating: 5,
      color: 'from-gold-light/40 to-amber-50/20'
    },
    { 
      name: 'יעל מ.', 
      role: 'סטודנטית בת 24', 
      highlight: 'האתגר הזה נתן לי את הכוח לקחת פיקוד',
      text: 'החלטתי שאני לא נותנת למצב הכלכלי במדינה להכתיב לי את העתיד. האתגר הזה נתן לי את הכוח והכלים לקחת פיקוד.', 
      rating: 5,
      color: 'from-yellow-50/50 to-amber-50/30'
    },
    { 
      name: 'שי וקרן א.', 
      role: 'זוג נשוי + 3, חולון', 
      highlight: 'ביטחון כלכלי אמיתי', 
      text: 'הגענו למצב של חנק חודשי. בזכות מעוז אנחנו חיים היום עם ביטחון כלכלי אמיתי ובלי המריבות הקבועות על כסף בסוף החודש.', 
      rating: 5, 
      color: 'from-amber-50/50 to-orange-50/30' 
    },
    { 
      name: 'אביב מלכה', 
      role: 'עצמאי, באר שבע', 
      highlight: 'החזיר לי את השקט הנפשי', 
      text: 'כעצמאי, חוסר היציבות של ההכנסות גמר אותי. האתגר הזה פשוט החזיר לי את השקט הנפשי שלי ונתן לי שליטה מלאה ברווחים.', 
      rating: 5, 
      color: 'from-blue-50/50 to-teal-50/30' 
    },
    { 
      name: 'אורלי ק.', 
      role: 'אמא חד הורית, חיפה', 
      highlight: 'שינוי המציאות מקצה לקצה', 
      text: 'חשבתי שלפרוע את החובות האלו ייקח לי חיים שלמים. האתגר הראה לי דרך מעשית של שינוי המציאות מקצה לקצה בלי תירוצים.', 
      rating: 5, 
      color: 'from-emerald-50/50 to-teal-50/30' 
    },
    { 
      name: 'תומר דוידי', 
      role: 'סטודנט, אריאל', 
      highlight: 'שיעורים קצרים שתכלס עובדים', 
      text: 'החומר הדיגיטלי הזה הוא זהב. מעוז מעביר את הכל בגובה העיניים עם שיעורים קצרים שתכלס עובדים בשטח ובקבוצות זמן קטנות.', 
      rating: 5, 
      color: 'from-yellow-50/50 to-orange-50/30' 
    },
    { 
      name: 'גלית וארז', 
      role: 'בני 40, מודיעין', 
      highlight: 'יצאנו מחוב של 120 אלף', 
      text: 'היינו בטוחים שנצטרך לקחת עוד הלוואה כדי לכסות את המינוס. תוך מספר חודשים יצאנו מחוב של 120 אלף שקלים והתחלנו לחסוך באמת.', 
      rating: 5, 
      color: 'from-amber-50/40 to-yellow-50/20' 
    },
    { 
      name: 'שמעון ל.', 
      role: 'פנסיונר, נהריה', 
      highlight: 'אף פעם לא מאוחר ללמוד', 
      text: 'חשבתי שכלכלת המשפחה זה לצעירים בלבד. מעוז לימד אותי שאין גיל ליציבות פיננסית ושמחה. אף פעם לא מאוחר ללמוד וליצור התחלה חדשה.', 
      rating: 5, 
      color: 'from-rose-50/50 to-orange-50/30' 
    },
    { 
      name: 'ענבל ש.', 
      role: 'הייטק, רמת גן', 
      highlight: 'להסתכל על המספרים בלי לעגל פינות', 
      text: 'ההרגל החשוב שקיבלתי מהאתגר הוא פשוט להסתכל על המספרים בלי לעגל פינות. קיבלתי שליטה ואומץ שלא היו לי מעולם.', 
      rating: 5, 
      color: 'from-emerald-50/50 to-teal-50/30' 
    },
    { 
      name: 'נדב פ.', 
      role: 'נשוי טרי, ירושלים', 
      highlight: 'התחלנו את החיים ברגל ימין', 
      text: 'כזוג צעיר בתחילת הדרך, קבלת ההחלטות הכלכליות הייתה מבלבלת ומפחידה. בזכות הכלים כאן התחלנו את החיים ברגל ימין ובביטחון מלא.', 
      rating: 5, 
      color: 'from-gold-light/40 to-amber-50/20' 
    },
    { 
      name: 'יסמין אלון', 
      role: 'מעצבת פנים, פתח תקווה', 
      highlight: 'עובד על ההרגלים הכי קטנים', 
      text: 'האתגר הזה בנוי בצורה גאונית כי הוא עובד על ההרגלים הכי קטנים ביום יום. קל מאוד להתמדה ומביא תוצאות מהר מהצפוי.', 
      rating: 5, 
      color: 'from-yellow-50/50 to-amber-50/30' 
    },
    { 
      name: 'אלון ח.', 
      role: 'הנדסאי, כפר סבא', 
      highlight: 'ניתוח סיכונים וכדאיות כלכלית', 
      text: 'הייתי סקפטי בהתחלה אבל השיעורים של מעוז על ניתוח סיכונים וכדאיות כלכלית פתחו לי את העיניים. השקעה מטורפת בעתיד הילדים שלי.', 
      rating: 5, 
      color: 'from-blue-50/40 to-indigo-50/20' 
    },
    { 
      name: 'רויטל ויוסי', 
      role: 'הורים ל-4, עפולה', 
      highlight: 'פתר לנו מחלוקות של שנים', 
      text: 'הלימוד המשותף דרך המדריך פשוט פתר לנו מחלוקות של שנים סביב ההוצאות והקניות. היום אנחנו פועלים כצוות אחד מנצח.', 
      rating: 5, 
      color: 'from-amber-50/50 to-orange-50/30' 
    },
    { 
      name: 'בר א.', 
      role: 'בת 28, אשדוד', 
      highlight: 'הפסקתי לפחד מהבנקים והחובות', 
      text: 'כל חודש היה מלווה בחרדה וטלפונים מהבנק. אחרי 45 ימי אתגר, הפסקתי לפחד מהבנקים והחובות שלי ועברתי למצב של חסכון צומח.', 
      rating: 5, 
      color: 'from-rose-50/50 to-orange-50/30' 
    }
  ];

  return (
    <section className="py-16 bg-navy-deep border-t border-white/5" id="testimonials" dir="rtl">
      <div className="container mx-auto px-6 max-w-5xl">
        <SectionHeading 
          title="סיפורי הצלחה מהשטח"
          subtitle="אנשים אמיתיים, תוצאות אמיתיות. ב-2026 השליטה היא כבר לא אופציה – היא חובה להתחלה חדשה."
          inverted={true}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          {testimonials.map((t, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.08, duration: 0.5 }}
              whileHover={{ y: -6, scale: 1.02 }}
              className="p-6 rounded-3xl bg-navy-medium border border-gold-premium/10 hover:border-gold-premium/40 shadow-xl transition-all duration-300 text-right flex flex-col justify-between relative overflow-hidden group"
            >
              {/* Highlight ribbon accent */}
              <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-gold-premium to-gold-hover opacity-60" />

              <div>
                {/* Visual quote indicator & ratings */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex gap-0.5 text-gold-premium scale-90">
                    {[...Array(t.rating)].map((_, i) => (
                      <span key={i} className="text-sm">★</span>
                    ))}
                  </div>
                  <span className="text-[10px] font-black px-2.5 py-0.5 bg-navy-deep border border-gold-premium/25 rounded-full text-gold-premium">
                    משוב מאומת
                  </span>
                </div>

                <p className="text-slate-300 font-bold text-sm leading-relaxed mb-6 block relative">
                  {/* Styled Quote */}
                  <span className="text-2xl text-gold-premium absolute right-[-10px] top-[-15px] opacity-40">"</span>
                  {t.text.split(t.highlight)[0]}
                  <span className="inline-block px-1.5 py-0.5 bg-gold-premium/10 text-gold-premium rounded-md font-black italic border-b border-gold-premium/30">
                    {t.highlight}
                  </span>
                  {t.text.split(t.highlight)[1]}
                  <span className="text-2xl text-gold-premium select-none opacity-40">"</span>
                </p>
              </div>

              {/* Author Info */}
              <div className="flex items-center gap-3 border-t border-white/5 pt-4 mt-auto">
                <div className="w-10 h-10 bg-gold-premium text-navy-deep rounded-2xl flex items-center justify-center font-black text-sm shadow-md shadow-gold-premium/10">
                  {t.name[0]}
                </div>
                <div>
                  <div className="font-extrabold text-white text-sm">{t.name}</div>
                  <div className="text-slate-400 font-bold text-xs">{t.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const FAQ = () => {
  const faqs = [
    { 
      q: 'אני חייב ללמוד לנהל את הכסף שלי האם אני נמצא במקום הנכון?', 
      a: 'חד משמעית כן. אין כאן קסם. זה לא הולך להיות קל. אין לעגל פינות ולעגל מספרים כלפי מעלה או למטה. מסתכלים על המספרים בדיוק כפי שהם. האתגר הזה מציג לך את המציאות כמו שהיא אצלך בעיניים פקוחות ובאומץ רב. כאשר תלמדו את 40 שיעורים אתם כבר בדרך להתחלה החדשה שלכם. אם בא לכם לאתגר את עצמכם עוד תבצעו גם את האתגר 45 יום להתחלה החדשה שלכם.' 
    },
    { 
      q: 'מאיזה גיל זה מתאים?', 
      a: 'ליוויתי בחיי בני נוער ומבוגרים וגם כאלו שהיו בני 67 והלאה. האתגר בנוי כך שהוא מתאים לכולם!!! לכל מי שחייב ורוצה לשפר את המצב הכלכלי נוכחי שבו הוא נמצא כיום.' 
    },
    { 
      q: 'כמה זמן עליי להקדיש לזה ביום?', 
      a: 'השיעורים קצרים, פרקטיים ובנויים כך שיהיה נוח וקל לכולם בכל זמן ובכל מקום. כל שיעור בנוי עד 30 דק - זמין ונוח להאזנה בכל מקום ובכל זמן.' 
    },
    { 
      q: 'למי זה מתאים?', 
      a: 'לכל מי שמוכן לקחת אחריות על ההווה והעתיד הכלכליים שלו. לכל מי שיש לו יכולת למידה עצמית ורצון לשפר את איכות החיים שלו. לכל מי שרוצה לדעת עוד על איך להתנהל עם הכסף שלו. לכל מי שלא חוסך עכשיו כסף ורוצה לדעת איך לעשות את זה. לכל מי שרוצה לשפר את המצב הכלכלי הנוכחי שלו שבו הוא נמצא כיום. והכי חשוב מתאים למי שלא דואג מאתגרים בחיים.' 
    },
    { 
      q: 'מזה האתגר הזה?', 
      a: 'אתגר בנוי כך שבכל יום יש לכם משימה לבצע. עליכם לבצע את האתגר הזה 45 יום רצוף ככל האפשר יום אחר יום ולרשום לעצמכם את זה במחברת כדי לעקוב אחר ההתקדמות שלכם. בנוסף, אתם מקבלים 40 שיעורים דיגיטליים במתנה כדי שיסייע לכם להצליח את האתגר הזה ולסיים אותו בהצלחה.' 
    },
    { 
      q: 'האם יש התחייבות להצלחה?', 
      a: 'לא. לא. לא. האתגר והשיעורים מוקלטים והם ללמידה עצמית בכל מקום ובכל זמן. הגישה מוגבלת לשנה! ההצלחה שלך תלוייה אך ורק בך. כאן נמצאים הכלים שיעזרו לך בהווה ובעתיד עליך לדעת לחקור ולהתאים אותם בשימוש היום יומי שלך.' 
    },
    { 
      q: 'האתגר הזה ״יביא לי עוד״ כסף?', 
      a: 'חד משמעית לא. אין כאן קסם. זה לא הולך להיות קל. אין לעגל פינות ולעגל מספרים כלפי מעלה או למטה. מסתכלים על המספרים בדיוק כפי שהם. האתגר הזה מציג לך את המציאות כמו שהיא אצלך בעיניים פקוחות ובאומץ רב. כאשר תלמדו את 40 שיעורים שקיבלתם במתנה ותבצעו את האתגר 45 יום ותבצעו כל מה שכתוב במדריך הכלכלי דיגיטלי "אדר התחלה חדשה 40 שיעורים + אתגר כלכלי דיגיטלי 45 יום" אתם בהחלט תשפרו לעצמכם עם הידע והכלים שתרכשו כאן את הידע הכלכלי בהווה והעתיד שלכם ושל הקרובים שלכם.' 
    },
    { 
      q: 'איך אתה ממליץ לי לבצע את האתגר?', 
      a: 'כאחד שמתמודד עם קשב וריכוז בדרגה אחרת ממה שאתם מכירים אני תמיד ממליץ לכתוב במחברת כל שיעור ושיעור ולתעד בעוד מחברת או יומן את ההתמודדות שלי האמיתית כל יום עם כסף וכל מה שאני חושב עליו. אני מציע לעבור על כל השיעורים והאתגר פעם אחר פעם אחר פעם ועוד פעם עד שתשלטו בעקרונות החשובים ביותר באתגר הזה.' 
    }
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="py-16 bg-white border-t border-slate-150" id="faq" dir="rtl">
      <div className="container mx-auto px-6 max-w-3xl">
        <SectionHeading title="כל מה שרציתם לדעת על האתגר" subtitle="שאלות ותשובות נפוצות" inverted={false} titleClassName="text-black" />
        
        <div className="space-y-2.5">
          {faqs.map((faq, index) => (
            <div key={index} className="border border-gold-premium/15 rounded-xl overflow-hidden bg-slate-50 transition-all duration-300 shadow-xs">
              <button 
                className="w-full p-4 text-right flex items-center justify-between hover:bg-slate-100/50 transition-colors"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <span className="text-base font-black text-slate-900">{faq.q}</span>
                <ChevronDown className={cn("w-4 h-4 text-gold-premium transition-transform", openIndex === index && "rotate-180")} />
              </button>
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                  >
                    <div className="px-4 pb-4 text-slate-700 font-semibold text-sm leading-relaxed border-t border-slate-200/60 pt-3">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section className="py-16 bg-navy-deep border-t border-white/5" id="contact-form">
      <div className="container mx-auto px-6">
        <div className="max-w-xl mx-auto">
          <ContactCard />
        </div>
      </div>
    </section>
  );
};

const Footer = ({ onLogoClick }: { onLogoClick?: () => void }) => (
  <footer className="bg-navy-deep py-12 border-t border-white/5">
    <div className="container mx-auto px-6 text-center">
      <div 
        className="flex flex-col items-center justify-center gap-2 mb-6 cursor-pointer select-none active:scale-95 transition-transform"
        onClick={onLogoClick}
        title="מעוז אדר"
      >
        <Logo variant="vertical" color="light" />
      </div>
      
      <div className="flex flex-wrap justify-center gap-6 mb-6 text-slate-400 text-xs font-bold uppercase tracking-wider">
        <a href="#challenge" className="hover:text-gold-premium transition-colors">אתגר 45 יום</a>
        <a href="#about" className="hover:text-gold-premium transition-colors">אודות</a>
        <a href="#faq" className="hover:text-gold-premium transition-colors">שאלות</a>
      </div>
      
      <p className="text-xs text-slate-500 font-medium tracking-wider">
        © {new Date().getFullYear()} מעוז אדר - כל הזכויות שמורות.
      </p>
    </div>
  </footer>
);

const FloatingWhatsApp = () => (
  <a 
    href="https://wa.me/972542516100?text=%D7%94%D7%99%D7%99%20%D7%90%D7%A0%D7%99%20%D7%9E%D7%A2%D7%95%D7%A0%D7%99%D7%99%D7%9F%20%D7%9C%D7%A9%D7%9E%D7%95%D7%A2%20%D7%A4%D7%A8%D7%98%D7%99%D7%9D%20%D7%A2%D7%9C%20%D7%94%D7%90%D7%AA%D7%92%D7%A8" 
    target="_blank" 
    className="fixed bottom-24 right-6 md:bottom-10 md:right-10 z-40 bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:scale-110 active:scale-95 transition-all duration-300"
    aria-label="WhatsApp"
  >
    <MessageCircle className="w-8 h-8 md:w-10 md:h-10 fill-white" />
  </a>
);

const MobileBottomBar = () => (
  <div className="md:hidden fixed bottom-0 left-0 w-full bg-navy-medium/95 backdrop-blur-md border-t border-gold-premium/20 p-4 flex gap-4 z-50">
    <Button 
      variant="wa" 
      className="flex-1 py-3" 
      onClick={() => window.open('https://wa.me/972542516100?text=%D7%94%D7%99%D7%99%20%D7%90%D7%A0%D7%99%20%D7%9E%D7%A2%D7%95%D7%A0%D7%99%D7%99%D7%9F%20%D7%9C%D7%A9%D7%9E%D7%95%D7%A2%20%D7%A4%D7%A8%D7%98%D7%99%D7%9D%20%D7%A2%D7%9C%20%D7%94%D7%90%D7%AA%D7%92%D7%A8')}
    >
      Whatsapp
      <MessageCircle className="w-5 h-5" />
    </Button>
    <Button 
      variant="primary" 
      className="flex-2 py-3 bg-gold-premium text-navy-deep hover:bg-gold-hover border border-gold-premium font-black" 
      onClick={() => document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' })}
    >
      להצטרפות
      <ArrowRight className="w-5 h-5 rtl:rotate-180" />
    </Button>
  </div>
);

const AccessibilityWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [settings, setSettings] = useState({
    fontSize: 100,
    grayscale: false,
    highContrast: false,
    underlineLinks: false,
    readableFont: false,
  });

  useEffect(() => {
    const html = document.documentElement;
    html.style.fontSize = `${settings.fontSize}%`;
    
    if (settings.grayscale) html.classList.add('accessibility-grayscale');
    else html.classList.remove('accessibility-grayscale');

    if (settings.highContrast) html.classList.add('accessibility-high-contrast');
    else html.classList.remove('accessibility-high-contrast');

    if (settings.underlineLinks) html.classList.add('accessibility-underline');
    else html.classList.remove('accessibility-underline');

    if (settings.readableFont) html.classList.add('accessibility-readable');
    else html.classList.remove('accessibility-readable');

  }, [settings]);

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const changeFontSize = (delta: number) => {
    setSettings(prev => ({ ...prev, fontSize: Math.min(Math.max(prev.fontSize + delta, 80), 150) }));
  };

  const resetSettings = () => {
    setSettings({
      fontSize: 100,
      grayscale: false,
      highContrast: false,
      underlineLinks: false,
      readableFont: false,
    });
  };

  return (
    <div className="fixed bottom-24 left-6 md:bottom-10 md:left-10 z-50">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="bg-gold-premium text-navy-deep p-4 rounded-full shadow-lg hover:scale-110 active:scale-95 transition-all duration-300"
        aria-label="תפריט נגישות"
      >
        <Accessibility className="w-8 h-8 md:w-10 md:h-10" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, x: -20, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: -20, scale: 0.9 }}
            className="absolute bottom-full mb-4 left-0 w-72 bg-navy-medium border border-gold-premium/20 rounded-2xl shadow-2xl overflow-hidden p-6 text-right"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-black text-white flex items-center gap-2">
                <Accessibility className="w-5 h-5 text-gold-premium" />
                תפריט נגישות
              </h3>
              <button 
                onClick={() => setIsOpen(false)}
                className="text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="flex flex-col gap-2">
                <label className="text-sm font-bold text-slate-400">גודל גופן</label>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => changeFontSize(-10)}
                    className="flex-1 bg-navy-deep border border-gold-premium/15 py-2 rounded-lg font-bold text-white hover:bg-navy-deep/60 transition-colors"
                  >
                    א-
                  </button>
                  <span className="px-4 font-bold text-white">{settings.fontSize}%</span>
                  <button 
                    onClick={() => changeFontSize(10)}
                    className="flex-1 bg-navy-deep border border-gold-premium/15 py-2 rounded-lg font-bold text-white hover:bg-navy-deep/60 transition-colors"
                  >
                    א+
                  </button>
                </div>
              </div>

              <button 
                onClick={() => toggleSetting('highContrast')}
                className={cn(
                  "w-full flex items-center justify-between p-3 rounded-xl border transition-all",
                  settings.highContrast ? "bg-gold-premium text-navy-deep border-gold-premium" : "bg-navy-deep border-gold-premium/10 text-slate-300 hover:border-gold-premium/30"
                )}
              >
                <span className="font-bold">ניגודיות גבוהה</span>
                <Eye className="w-5 h-5" />
              </button>

              <button 
                onClick={() => toggleSetting('grayscale')}
                className={cn(
                  "w-full flex items-center justify-between p-3 rounded-xl border transition-all",
                  settings.grayscale ? "bg-gold-premium text-navy-deep border-gold-premium" : "bg-navy-deep border-gold-premium/10 text-slate-300 hover:border-gold-premium/30"
                )}
              >
                <span className="font-bold">תצוגת אפור</span>
                <Sparkles className="w-5 h-5" />
              </button>

              <button 
                onClick={() => toggleSetting('underlineLinks')}
                className={cn(
                  "w-full flex items-center justify-between p-3 rounded-xl border transition-all",
                  settings.underlineLinks ? "bg-gold-premium text-navy-deep border-gold-premium" : "bg-navy-deep border-gold-premium/10 text-slate-300 hover:border-gold-premium/30"
                )}
              >
                <span className="font-bold">הדגשת קישורים</span>
                <Target className="w-5 h-5" />
              </button>

              <button 
                onClick={() => toggleSetting('readableFont')}
                className={cn(
                  "w-full flex items-center justify-between p-3 rounded-xl border transition-all",
                  settings.readableFont ? "bg-gold-premium text-navy-deep border-gold-premium" : "bg-navy-deep border-gold-premium/10 text-slate-300 hover:border-gold-premium/30"
                )}
              >
                <span className="font-bold">גופן קריא</span>
                <Type className="w-5 h-5" />
              </button>

              <button 
                onClick={resetSettings}
                className="w-full flex items-center justify-center gap-2 p-3 rounded-xl border border-dashed border-gold-premium/25 text-slate-400 hover:bg-white/5 transition-all mt-4"
              >
                <RotateCcw className="w-4 h-4" />
                איפוס הגדרות
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [logoClickCount, setLogoClickCount] = useState(0);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('admin') === 'true' || urlParams.get('admin') === 'maoz') {
        setIsAdmin(true);
      }
    }
  }, []);

  const handleLogoClick = () => {
    setLogoClickCount(prev => {
      const nextCount = prev + 1;
      if (nextCount >= 5) {
        setIsAdmin(true);
        alert("מצב מנהל הופעל בהצלחה! לוח הבקרה זמין כעת בתחתית הדף.");
        return 0;
      }
      return nextCount;
    });
  };

  return (
    <div className="min-h-screen overflow-x-hidden w-full relative">
      <Header />
      <main className="pb-24 md:pb-0">
        <Hero />
        <PersonalJourney />
        <About />
        <SurvivalState />
        <AfterChallenge />
        <Challenge />
        <Benefits />
        <Syllabus />
        <Pricing />
        <Testimonials />
        <FAQ />
        <Contact />
        {isAdmin && <AdminDashboard />}
      </main>
      <Footer onLogoClick={handleLogoClick} />
      <FloatingWhatsApp />
      <MobileBottomBar />
      <AccessibilityWidget />
    </div>
  );
}
