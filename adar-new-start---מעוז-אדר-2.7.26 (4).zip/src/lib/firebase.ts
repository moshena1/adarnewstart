import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User } from 'firebase/auth';
import { getFirestore, collection, addDoc, getDocs, doc, setDoc, query, orderBy, Timestamp, serverTimestamp } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId || '(default)');

const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/spreadsheets');

let isSigningIn = false;
let cachedAccessToken: string | null = null;

export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get access token from Firebase Auth');
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Sign in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const logout = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};

export interface Lead {
  id?: string;
  name: string;
  phone: string;
  email: string;
  createdAt: any;
  syncedToSheets?: boolean;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Save lead to cloud database (Firestore)
export async function saveLeadToCloud(lead: Omit<Lead, 'createdAt'>) {
  const path = 'leads';
  try {
    const leadsCol = collection(db, path);
    const docRef = await addDoc(leadsCol, {
      ...lead,
      createdAt: serverTimestamp(),
      syncedToSheets: false
    });
    return docRef.id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
    throw err;
  }
}

// Get all leads from cloud database (Firestore)
export async function getLeadsFromCloud(): Promise<Lead[]> {
  const path = 'leads';
  try {
    const leadsCol = collection(db, path);
    const q = query(leadsCol, orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Lead[];
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
    return [];
  }
}

// Mark lead as synced
export async function markLeadAsSynced(leadId: string) {
  const path = `leads/${leadId}`;
  try {
    const leadDoc = doc(db, 'leads', leadId);
    await setDoc(leadDoc, { syncedToSheets: true }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

// Save spreadsheet settings
export async function saveSettingsToCloud(settings: { spreadsheetId: string; targetEmail: string; scriptUrl?: string }) {
  const path = 'settings/sheets';
  try {
    const settingsDoc = doc(db, 'settings', 'sheets');
    await setDoc(settingsDoc, settings);
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, path);
  }
}

// Get spreadsheet settings
export async function getSettingsFromCloud(): Promise<{ spreadsheetId: string; targetEmail: string; scriptUrl?: string } | null> {
  const path = 'settings';
  try {
    const snapshot = await getDocs(collection(db, path));
    const docSnap = snapshot.docs.find(d => d.id === 'sheets');
    if (docSnap) {
      return docSnap.data() as { spreadsheetId: string; targetEmail: string; scriptUrl?: string };
    }
    return null;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
    return null;
  }
}

// Google Sheets API Helpers
export async function createSpreadsheet(accessToken: string, title: string) {
  const url = 'https://sheets.googleapis.com/v4/spreadsheets';
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: title,
      },
    }),
  });
  
  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Sheets API error: ${errText}`);
  }
  
  const data = await response.json();
  return {
    spreadsheetId: data.spreadsheetId,
    spreadsheetUrl: data.spreadsheetUrl,
  };
}

export async function appendRowToSheet(accessToken: string, spreadsheetId: string, rowValues: string[][]) {
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/A1:append?valueInputOption=USER_ENTERED`;
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      values: rowValues,
    }),
  });
  
  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Sheets API error: ${errText}`);
  }
  
  return response.json();
}

// Sync single lead to Google Sheets via Google Apps Script Web App
export async function syncLeadToAppsScript(scriptUrl: string, lead: { name: string; phone: string; email?: string }) {
  try {
    const localDateStr = new Date().toLocaleString('he-IL', { timeZone: 'Asia/Jerusalem' });
    
    await fetch(scriptUrl, {
      method: 'POST',
      mode: 'no-cors', // Avoid complex CORS preflight issues with Google Apps Script Web Apps
      headers: {
        'Content-Type': 'text/plain;charset=utf-8',
      },
      body: JSON.stringify({
        date: localDateStr,
        name: lead.name,
        phone: lead.phone,
        email: lead.email || 'לא צוין',
      }),
    });
    return true;
  } catch (err) {
    console.error('Failed automatic sync to Google Sheet via Apps Script:', err);
    return false;
  }
}

