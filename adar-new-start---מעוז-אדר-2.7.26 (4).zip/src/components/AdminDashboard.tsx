import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  FileSpreadsheet, 
  User, 
  Mail, 
  Settings, 
  Trash2, 
  Plus, 
  LogOut, 
  Lock, 
  RefreshCw, 
  Database,
  Eye,
  AlertTriangle,
  ExternalLink
} from 'lucide-react';
import { 
  initAuth, 
  googleSignIn, 
  logout, 
  getLeadsFromCloud, 
  getSettingsFromCloud, 
  saveSettingsToCloud, 
  createSpreadsheet, 
  appendRowToSheet, 
  markLeadAsSynced,
  Lead,
  db
} from '../lib/firebase';
import { cn } from '../lib/utils';

export default function AdminDashboard() {
  const [user, setUser] = useState<any>(null);
  const [token, setToken] = useState<string | null>(null);
  const [needsAuth, setNeedsAuth] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [showAppsScriptGuide, setShowAppsScriptGuide] = useState(false);
  
  // Leads and Settings
  const [leads, setLeads] = useState<Lead[]>([]);
  const [settings, setSettings] = useState({ spreadsheetId: '', targetEmail: 'moshenadri1@gmail.com', scriptUrl: '' });
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isCreatingSheet, setIsCreatingSheet] = useState(false);
  const [isLoadingLeads, setIsLoadingLeads] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  
  // Custom Delete Confirmation Modal State
  const [leadToDelete, setLeadToDelete] = useState<Lead | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Initialize auth listener
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, currentToken) => {
        setUser(currentUser);
        setToken(currentToken);
        setNeedsAuth(false);
      },
      () => {
        setUser(null);
        setToken(null);
        setNeedsAuth(true);
      }
    );
    return () => unsubscribe();
  }, []);

  // Fetch data if user is authenticated
  useEffect(() => {
    if (user) {
      fetchLeadsAndSettings();
    }
  }, [user]);

  const fetchLeadsAndSettings = async () => {
    setIsLoadingLeads(true);
    try {
      const dbLeads = await getLeadsFromCloud();
      setLeads(dbLeads);
      
      const dbSettings = await getSettingsFromCloud();
      if (dbSettings) {
        setSettings({
          spreadsheetId: dbSettings.spreadsheetId || '',
          targetEmail: dbSettings.targetEmail || 'moshenadri1@gmail.com',
          scriptUrl: dbSettings.scriptUrl || ''
        });
      } else {
        setSettings(prev => ({ ...prev, targetEmail: 'moshenadri1@gmail.com', scriptUrl: '' }));
      }
    } catch (err) {
      console.error("Error loading admin data:", err);
    } finally {
      setIsLoadingLeads(false);
    }
  };

  const handleLogin = async () => {
    setIsLoggingIn(true);
    setStatusMessage(null);
    try {
      const result = await googleSignIn();
      if (result) {
        setUser(result.user);
        setToken(result.accessToken);
        setNeedsAuth(false);
        showStatus('success', 'מחובר בהצלחה לחשבון גוגל!');
      }
    } catch (err: any) {
      console.error('Login failed:', err);
      showStatus('error', 'התחברות נכשלה. אנא ודא שאישרת את ההרשאות הדרושות.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      setUser(null);
      setToken(null);
      setNeedsAuth(true);
      setLeads([]);
      showStatus('info', 'התנתקת בהצלחה.');
    } catch (err) {
      console.error('Logout failed:', err);
    }
  };

  const showStatus = (type: 'success' | 'error' | 'info', text: string) => {
    setStatusMessage({ type, text });
    setTimeout(() => {
      setStatusMessage(null);
    }, 5000);
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);
    try {
      // If user pasted a full URL, extract the Spreadsheet ID
      let sheetId = settings.spreadsheetId.trim();
      const urlMatch = sheetId.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
      if (urlMatch && urlMatch[1]) {
        sheetId = urlMatch[1];
      }
      
      const updatedSettings = {
        spreadsheetId: sheetId,
        targetEmail: settings.targetEmail.trim(),
        scriptUrl: settings.scriptUrl.trim()
      };
      
      await saveSettingsToCloud(updatedSettings);
      setSettings(updatedSettings);
      showStatus('success', 'ההגדרות נשמרו בהצלחה בבסיס הנתונים בענן!');
    } catch (err) {
      console.error("Failed to save settings:", err);
      showStatus('error', 'שגיאה בשמירת ההגדרות.');
    } finally {
      setIsSavingSettings(false);
    }
  };

  const handleCreateNewSheet = async () => {
    if (!token) {
      showStatus('error', 'עלייך להתחבר מחדש עם גוגל על מנת לקבל אסימון גישה.');
      return;
    }
    
    setIsCreatingSheet(true);
    try {
      // Create spreadsheet
      const sheetName = `אתר מעוז לידים - ${new Date().toLocaleDateString('he-IL')}`;
      const result = await createSpreadsheet(token, sheetName);
      
      // Write headers row
      await appendRowToSheet(token, result.spreadsheetId, [
        ["תאריך ושעת רישום", "שם מלא של הליד", "מספר טלפון ליצירת קשר", "כתובת אימייל", "סטטוס סנכרון לענן"]
      ]);
      
      const updatedSettings = {
        spreadsheetId: result.spreadsheetId,
        targetEmail: user?.email || settings.targetEmail,
        scriptUrl: settings.scriptUrl
      };
      
      await saveSettingsToCloud(updatedSettings);
      setSettings(updatedSettings);
      showStatus('success', `גיליון חדש נוצר וחובר בהצלחה! שם: ${sheetName}`);
    } catch (err: any) {
      console.error("Failed to create sheet:", err);
      showStatus('error', 'יצירת הגיליון נכשלה. יש לוודא שיש לך הרשאת גישה מלאה לגוגל דרייב.');
    } finally {
      setIsCreatingSheet(false);
    }
  };

  const handleSyncLeads = async () => {
    if (!token) {
      showStatus('error', 'נא להתחבר מחדש לגוגל על מנת לבצע סנכרון.');
      return;
    }
    if (!settings.spreadsheetId) {
      showStatus('error', 'יש להגדיר מזהה גיליון (Spreadsheet ID) תחילה או ליצור גיליון חדש.');
      return;
    }
    
    const unsyncedLeads = leads.filter(l => !l.syncedToSheets);
    if (unsyncedLeads.length === 0) {
      showStatus('info', 'אין לידים חדשים לסנכרון. כל הלידים מסונכרנים כהלכה!');
      return;
    }
    
    setIsSyncing(true);
    let successCount = 0;
    
    try {
      // Prepare rows
      const rowsToAppend = unsyncedLeads.map(lead => {
        const localDateStr = lead.createdAt 
          ? new Date(lead.createdAt.seconds * 1000).toLocaleString('he-IL') 
          : new Date().toLocaleString('he-IL');
        return [
          localDateStr,
          lead.name,
          lead.phone,
          lead.email || 'לא צוין',
          'מסונכרן לענן'
        ];
      });
      
      // Append to sheet in one batch
      await appendRowToSheet(token, settings.spreadsheetId, rowsToAppend);
      
      // Update in Firestore
      for (const lead of unsyncedLeads) {
        if (lead.id) {
          await markLeadAsSynced(lead.id);
          successCount++;
        }
      }
      
      // Refresh list
      await fetchLeadsAndSettings();
      showStatus('success', `סונכרנו בהצלחה ${successCount} לידים לגיליון הגוגל שיטס!`);
    } catch (err: any) {
      console.error("Failed to sync leads:", err);
      showStatus('error', 'הסנכרון נכשל. ודא שמזהה הגיליון נכון ושיש לך הרשאות כתיבה.');
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <section className="py-16 bg-navy-deep text-white border-t border-white/5" id="admin-dashboard" dir="rtl">
      <div className="container mx-auto px-6 max-w-5xl">
        <div className="text-center mb-10">
          <span className="inline-flex items-center gap-1.5 bg-gold-premium/10 border border-gold-premium/30 rounded-full px-4 py-1.5 text-xs font-black text-gold-premium mb-3">
            <Lock className="w-3.5 h-3.5" />
            מערכת ניהול לידים וסנכרון לענן
          </span>
          <h2 className="text-3xl font-black mb-3">שמירת לידים ישירות ב-Google Sheets או בענן</h2>
          <p className="text-slate-400 font-medium text-sm md:text-base max-w-2xl mx-auto">
            כלי מתקדם המאפשר לשמור את פרטי המצטרפים לאתגר ישירות בבסיס נתונים בענן (Firestore) ובסנכרון מהיר ואינטגרטיבי לקובץ Google Sheets לבחירתך.
          </p>
        </div>

        {needsAuth ? (
          // LOGIN PROMPT
          <div className="max-w-md mx-auto bg-navy-medium border border-gold-premium/20 p-8 rounded-3xl text-center shadow-2xl">
            <div className="w-16 h-16 bg-gold-premium/10 border border-gold-premium/30 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Database className="w-8 h-8 text-gold-premium" />
            </div>
            <h3 className="text-xl font-black mb-2">חיבור מאובטח לחשבון Google Sheets</h3>
            <p className="text-slate-300 font-medium text-sm mb-6 leading-relaxed">
              על מנת לחבר את הטופס ישירות לגיליון הנתונים שלך ולנהל את הלידים, יש לבצע התחברות מאובטחת.
            </p>
            
            <button 
              onClick={handleLogin}
              disabled={isLoggingIn}
              className="gsi-material-button w-full flex justify-center py-1 cursor-pointer transition-transform active:scale-95"
              id="admin-login-btn"
            >
              <div className="gsi-material-button-state"></div>
              <div className="gsi-material-button-content-wrapper">
                <div className="gsi-material-button-icon">
                  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: 'block' }}>
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                    <path fill="none" d="M0 0h48v48H0z"></path>
                  </svg>
                </div>
                <span className="gsi-material-button-contents font-black text-slate-700">התחברות באמצעות Google</span>
              </div>
            </button>
            
            {isLoggingIn && (
              <p className="text-xs text-gold-premium font-bold mt-3 animate-pulse">מתחבר ומאמת מול שרתי Google...</p>
            )}
          </div>
        ) : (
          // LOGGED IN DASHBOARD
          <div className="space-y-6">
            {/* Status Messages */}
            {statusMessage && (
              <div className={cn(
                "p-4 rounded-xl flex items-center gap-3 border text-sm font-bold",
                statusMessage.type === 'success' ? "bg-emerald-950/40 border-emerald-500/30 text-emerald-300" :
                statusMessage.type === 'error' ? "bg-rose-950/40 border-rose-500/30 text-rose-300" :
                "bg-blue-950/40 border-blue-500/30 text-blue-300"
              )}>
                <CheckCircle2 className="w-5 h-5 shrink-0" />
                <span>{statusMessage.text}</span>
              </div>
            )}

            {/* Profile Bar */}
            <div className="bg-navy-medium border border-white/5 rounded-3xl p-5 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                {user?.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName} className="w-12 h-12 rounded-full border-2 border-gold-premium/40" />
                ) : (
                  <div className="w-12 h-12 bg-navy-deep border border-gold-premium/40 rounded-full flex items-center justify-center font-black">
                    {user?.displayName ? user.displayName[0] : 'U'}
                  </div>
                )}
                <div>
                  <h4 className="font-black text-white text-base leading-none mb-1.5">{user?.displayName || 'משתמש מחובר'}</h4>
                  <p className="text-xs font-bold text-slate-400">{user?.email}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <button 
                  onClick={fetchLeadsAndSettings}
                  className="p-3 bg-navy-deep hover:bg-navy-light border border-white/10 rounded-xl text-slate-300 transition-colors"
                  title="רענן נתונים"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
                <button 
                  onClick={handleLogout}
                  className="flex items-center gap-2 px-4 py-2.5 bg-rose-950/20 border border-rose-500/20 hover:border-rose-500/40 hover:bg-rose-950/40 transition-colors text-rose-300 rounded-xl font-bold text-xs"
                >
                  <LogOut className="w-4 h-4" />
                  התנתק
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* SETTINGS FORM */}
              <div className="lg:col-span-4 bg-navy-medium border border-gold-premium/15 rounded-3xl p-6 h-fit space-y-6">
                <div>
                  <h3 className="text-lg font-black text-white flex items-center gap-2 mb-1.5">
                    <Settings className="w-5 h-5 text-gold-premium" />
                    הגדרות סנכרון
                  </h3>
                  <p className="text-xs text-slate-400 font-semibold leading-relaxed">
                    חבר את טופס ההרשמה לגליון Google Sheets ספציפי או הגדר כתובת מייל ליעד.
                  </p>
                </div>

                <form onSubmit={handleSaveSettings} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300">קישור או מזהה גיליון גוגל (Spreadsheet ID)</label>
                    <input 
                      type="text"
                      placeholder="הדבק מזהה או קישור לגוגל שיטס"
                      value={settings.spreadsheetId}
                      onChange={e => setSettings({ ...settings, spreadsheetId: e.target.value })}
                      className="w-full bg-navy-deep border border-gold-premium/20 rounded-xl px-4 py-3 text-xs outline-none focus:border-gold-premium text-white placeholder-slate-600 font-mono"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300">כתובת Web App של Google Apps Script (לסנכרון אוטומטי מיידי)</label>
                    <input 
                      type="text"
                      placeholder="הדבק כתובת URL של Apps Script"
                      value={settings.scriptUrl}
                      onChange={e => setSettings({ ...settings, scriptUrl: e.target.value })}
                      className="w-full bg-navy-deep border border-gold-premium/20 rounded-xl px-4 py-3 text-xs outline-none focus:border-gold-premium text-white placeholder-slate-600 font-mono"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-300">מייל בעלים למשלוח וניהול</label>
                    <input 
                      type="email"
                      placeholder="maoz@example.com"
                      value={settings.targetEmail}
                      onChange={e => setSettings({ ...settings, targetEmail: e.target.value })}
                      className="w-full bg-navy-deep border border-gold-premium/20 rounded-xl px-4 py-3 text-xs outline-none focus:border-gold-premium text-white placeholder-slate-600"
                    />
                  </div>

                  <button 
                    type="submit"
                    disabled={isSavingSettings}
                    className="w-full py-3 bg-navy-deep hover:bg-navy-light text-gold-premium font-black text-xs border border-gold-premium/30 rounded-xl transition-colors shadow-sm"
                  >
                    {isSavingSettings ? 'שומר הגדרות...' : 'שמור הגדרות בענן'}
                  </button>
                </form>

                <div className="bg-navy-deep/40 p-1.5 rounded-2xl border border-white/5">
                  <button
                    type="button"
                    onClick={() => setShowAppsScriptGuide(!showAppsScriptGuide)}
                    className="w-full text-right text-[11px] text-gold-premium font-black hover:underline flex items-center justify-between p-2.5"
                  >
                    <span>הוראות להפעלת סנכרון אוטומטי מיידי 🚀</span>
                    <span>{showAppsScriptGuide ? '▲' : '▼'}</span>
                  </button>

                  {showAppsScriptGuide && (
                    <div className="p-3 text-right space-y-3 mt-1 border-t border-white/5">
                      <h4 className="text-[11px] font-black text-gold-premium">מדריך קצר לסנכרון אוטומטי מלא ב-3 צעדים:</h4>
                      <ol className="text-[10px] text-slate-300 space-y-2 list-decimal list-inside leading-relaxed font-semibold">
                        <li>פתחו את קובץ גוגל שיטס שלכם ("אתר מעוז לידים").</li>
                        <li>בתפריט העליון לחצו על <strong>הרחבות (Extensions) &larr; Apps Script</strong>.</li>
                        <li>מחקו את כל הקוד הקיים שם, והדביקו את הקוד הבא:</li>
                      </ol>
                      <div className="relative">
                        <pre className="bg-navy-deep text-slate-300 p-2 rounded-lg text-[9px] font-mono overflow-x-auto text-left select-all border border-white/5 max-h-40 overflow-y-auto">
{`function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    sheet.appendRow([
      data.date,
      data.name,
      data.phone,
      data.email,
      "סנכרון אוטומטי מיידי"
    ]);
    return ContentService.createTextOutput(JSON.stringify({ status: "success" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({ status: "error", message: error.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}`}
                        </pre>
                        <button
                          type="button"
                          onClick={() => navigator.clipboard.writeText(`function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    sheet.appendRow([
      data.date,
      data.name,
      data.phone,
      data.email,
      "סנכרון אוטומטי מיידי"
    ]);
    return ContentService.createTextOutput(JSON.stringify({ status: "success" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({ status: "error", message: error.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}`)}
                          className="absolute top-1.5 left-1.5 bg-navy-medium hover:bg-navy-deep text-[9px] text-gold-premium font-bold px-1.5 py-0.5 rounded border border-gold-premium/20 cursor-pointer"
                        >
                          העתק
                        </button>
                      </div>
                      <ol className="text-[10px] text-slate-300 space-y-2 list-decimal list-inside leading-relaxed font-semibold" start={4}>
                        <li>לחצו על סמל הדיסקט לשמירה, ואז לחצו על כפתור <strong>פריסה (Deploy) &larr; פריסה חדשה (New deployment)</strong>.</li>
                        <li>לחצו על גלגל השיניים ליד סוג הפריסה ובחרו <strong>אפליקציית אינטרנט (Web app)</strong>.</li>
                        <li>הגדירו:
                          <ul className="list-disc list-inside mr-4 mt-1 text-[9.5px] text-slate-400 font-medium">
                            <li>מריץ את האפליקציה כ: <strong>אני (Me)</strong></li>
                            <li>למי יש גישה: <strong>כולם (Anyone)</strong></li>
                          </ul>
                        </li>
                        <li>לחצו על <strong>פריסה (Deploy)</strong>, אשרו הרשאות גישה לגוגל שיטס שלכם, והעתיקו את <strong>כתובת ה-URL של אפליקציית האינטרנט</strong> שנוצרה.</li>
                        <li>הדביקו את הכתובת בשדה למעלה ולחצו על <strong>שמור הגדרות בענן</strong>. זה הכל!</li>
                      </ol>
                    </div>
                  )}
                </div>

                <div className="h-[1px] bg-white/5" />

                <div className="space-y-3">
                  <h4 className="text-xs font-black text-slate-300">פעולות מהירות בגוגל שיטס:</h4>
                  <button 
                    onClick={handleCreateNewSheet}
                    disabled={isCreatingSheet}
                    className="w-full py-3 bg-gradient-to-r from-emerald-900/30 to-emerald-950/20 hover:from-emerald-900/40 border border-emerald-500/20 hover:border-emerald-500/40 text-emerald-300 font-black text-xs rounded-xl transition-colors flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    {isCreatingSheet ? 'מייצר גיליון חדש...' : 'צור גיליון Google Sheets חדש'}
                  </button>
                  
                  {settings.spreadsheetId && (
                    <a 
                      href={`https://docs.google.com/spreadsheets/d/${settings.spreadsheetId}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-3 bg-navy-deep hover:bg-navy-light border border-white/5 text-slate-300 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      פתח גיליון נתונים נוכחי בגוגל
                    </a>
                  )}
                </div>

                {/* SHARING INFORMATION CALLOUT */}
                <div className="bg-navy-deep/60 border border-gold-premium/15 rounded-2xl p-4.5 space-y-2.5 text-right">
                  <h5 className="text-[11px] font-black text-gold-premium uppercase tracking-wider flex items-center gap-1.5 justify-end">
                    <span>כיצד לשתף את קובץ הלידים בעתיד?</span>
                  </h5>
                  <p className="text-[10.5px] text-slate-300 leading-relaxed font-semibold">
                    מכיוון שהגיליון שנוצר שמור ישירות בחשבון ה-Google Drive שלך, הוא שייך לך לחלוטין ותוכל לשתף אותו בקלות:
                  </p>
                  <ul className="text-[10px] text-slate-400 space-y-1 list-disc list-inside leading-relaxed font-medium">
                    <li>לחץ על הכפתור <strong>"פתח גיליון נתונים נוכחי בגוגל"</strong> שמופיע למעלה.</li>
                    <li>בתוך גוגל שיטס, לחץ על כפתור <strong>"שתף" (Share)</strong> בפינה העליונה.</li>
                    <li>הזן את כתובת האימייל של המשתמש שאיתו תרצה לשתף והגדר את הרשאות הצפייה או העריכה שלו.</li>
                  </ul>
                </div>
              </div>

              {/* LEADS LIST TABLE */}
              <div className="lg:col-span-8 bg-navy-medium border border-white/5 rounded-3xl p-6 flex flex-col justify-between min-h-[400px]">
                <div className="space-y-4">
                  <div className="flex items-center justify-between border-b border-white/5 pb-4">
                    <div>
                      <h3 className="text-lg font-black text-white flex items-center gap-2">
                        <Database className="w-5 h-5 text-gold-premium" />
                        לידים שנרשמו בבסיס הנתונים בענן
                      </h3>
                      <p className="text-xs text-slate-400 font-semibold mt-0.5">
                        סך הכל {leads.length} לידים רשומים. ({leads.filter(l => !l.syncedToSheets).length} ממתינים לסנכרון).
                      </p>
                    </div>

                    <button 
                      onClick={handleSyncLeads}
                      disabled={isSyncing || leads.filter(l => !l.syncedToSheets).length === 0}
                      className="flex items-center gap-2 px-4 py-2.5 bg-gold-premium text-navy-deep hover:bg-gold-hover disabled:opacity-50 disabled:hover:bg-gold-premium transition-colors rounded-xl font-black text-xs"
                    >
                      <FileSpreadsheet className="w-4 h-4" />
                      {isSyncing ? 'מסנכרן כעת...' : 'סנכרן את כולם ל-Sheets'}
                    </button>
                  </div>

                  {isLoadingLeads ? (
                    <div className="py-12 text-center text-slate-400 font-bold text-sm animate-pulse">
                      טוען לידים מתוך בסיס הנתונים בענן...
                    </div>
                  ) : leads.length === 0 ? (
                    <div className="py-16 text-center border-2 border-dashed border-white/5 rounded-2xl">
                      <Database className="w-12 h-12 text-slate-500 mx-auto mb-4" />
                      <p className="text-sm font-bold text-slate-400">טרם נתקבלו לידים במערכת.</p>
                      <p className="text-xs text-slate-500 mt-1">מלא את טופס יצירת הקשר באתר כדי לבדוק את השמירה בענן.</p>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-right text-xs">
                        <thead>
                          <tr className="border-b border-white/5 text-slate-400 font-bold uppercase tracking-wider">
                            <th className="pb-3 text-right">תאריך</th>
                            <th className="pb-3 text-right">שם מלא</th>
                            <th className="pb-3 text-right">טלפון</th>
                            <th className="pb-3 text-right">אימייל</th>
                            <th className="pb-3 text-center">סטטוס סנכרון</th>
                            <th className="pb-3 text-center">פעולות</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {leads.map((lead) => {
                            const formattedDate = lead.createdAt 
                              ? new Date(lead.createdAt.seconds * 1000).toLocaleDateString('he-IL') + ' ' + new Date(lead.createdAt.seconds * 1000).toLocaleTimeString('he-IL', {hour: '2-digit', minute:'2-digit'})
                              : 'לא ידוע';
                            return (
                              <tr key={lead.id} className="hover:bg-white/[0.02] transition-colors">
                                <td className="py-3.5 font-mono text-slate-400 font-bold">{formattedDate}</td>
                                <td className="py-3.5 font-bold text-white">{lead.name}</td>
                                <td className="py-3.5 font-bold text-slate-300 font-mono">{lead.phone}</td>
                                <td className="py-3.5 font-semibold text-slate-400">{lead.email || '-'}</td>
                                <td className="py-3.5 text-center">
                                  {lead.syncedToSheets ? (
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-950/40 border border-emerald-500/20 text-emerald-400 rounded-full text-[10px] font-bold">
                                      <CheckCircle2 className="w-3 h-3" />
                                      סונכרן לגוגל
                                    </span>
                                  ) : (
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-950/40 border border-amber-500/20 text-amber-400 rounded-full text-[10px] font-bold">
                                      <RefreshCw className="w-3 h-3 animate-spin" style={{ animationDuration: '3s' }} />
                                      ממתין
                                    </span>
                                  )}
                                </td>
                                <td className="py-3.5 text-center">
                                  <button 
                                    onClick={() => setLeadToDelete(lead)}
                                    className="p-1.5 bg-rose-950/20 border border-rose-500/10 hover:border-rose-500/40 hover:bg-rose-950/40 text-rose-300 rounded-lg transition-colors"
                                    title="מחק ליד"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* CUSTOM CONFIRMATION DELETE DIALOG */}
      <AnimatePresence>
        {leadToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm" dir="rtl">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-navy-medium border border-rose-500/30 p-8 rounded-3xl text-right shadow-2xl relative"
            >
              <div className="flex items-center gap-3 text-rose-400 mb-4">
                <AlertTriangle className="w-6 h-6 shrink-0" />
                <h3 className="text-xl font-black">האם אתה בטוח שברצונך למחוק ליד זה?</h3>
              </div>
              
              <div className="bg-navy-deep/60 p-4 border border-white/5 rounded-2xl mb-6 space-y-2">
                <p className="text-sm font-bold text-white"><span className="text-slate-400 ml-1.5">שם מלא:</span> {leadToDelete.name}</p>
                <p className="text-sm font-bold text-white"><span className="text-slate-400 ml-1.5">טלפון:</span> {leadToDelete.phone}</p>
                {leadToDelete.email && <p className="text-sm font-bold text-white"><span className="text-slate-400 ml-1.5">אימייל:</span> {leadToDelete.email}</p>}
              </div>

              <p className="text-slate-300 text-xs font-semibold leading-relaxed mb-6">
                שים לב: פעולה זו היא בלתי הפיכה ותמחק את הליד ישירות מבסיס הנתונים בענן Firestore.
              </p>

              <div className="flex items-center gap-3">
                <button 
                  onClick={async () => {
                    if (leadToDelete.id) {
                      setIsDeleting(true);
                      try {
                        const { deleteDoc, doc } = await import('firebase/firestore');
                        await deleteDoc(doc(db, 'leads', leadToDelete.id));
                        showStatus('success', 'הליד נמחק בהצלחה מבסיס הנתונים בענן.');
                        setLeadToDelete(null);
                        await fetchLeadsAndSettings();
                      } catch (err) {
                        console.error("Error deleting lead:", err);
                        showStatus('error', 'שגיאה במחיקת הליד.');
                      } finally {
                        setIsDeleting(false);
                      }
                    }
                  }}
                  disabled={isDeleting}
                  className="flex-1 py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black transition-colors"
                >
                  {isDeleting ? 'מוחק...' : 'כן, מחק ליד'}
                </button>
                <button 
                  onClick={() => setLeadToDelete(null)}
                  disabled={isDeleting}
                  className="flex-1 py-3 bg-navy-deep hover:bg-navy-light border border-white/10 text-slate-300 rounded-xl text-xs font-bold transition-colors"
                >
                  ביטול
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
